import React, { useState, useMemo } from 'react';
import { LIBRARY_CATEGORIES, LIBRARY_ITEMS } from '../lib/library-data';
import type { LibraryCategory, LibraryItem } from '../lib/types';
import { CodeBlockView } from './CodeBlockView';
import { Search, BookOpen, Tag, Sparkles, Filter, Check, ArrowRight } from 'lucide-react';
import { playSound } from '../lib/utils';

interface ScriptLibraryProps {
  onSendToSandbox: (code: string) => void;
  onOpenInWorkspace?: (item: LibraryItem) => void;
}

export function ScriptLibrary({ onSendToSandbox, onOpenInWorkspace }: ScriptLibraryProps) {
  const [selectedCategory, setSelectedCategory] = useState<LibraryCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeItem, setActiveItem] = useState<LibraryItem | null>(LIBRARY_ITEMS[0]);

  const filteredItems = useMemo(() => {
    return LIBRARY_ITEMS.filter((item) => {
      const matchCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const matchSearch =
        searchQuery === '' ||
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCategory && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      
      {/* Header Banner */}
      <div className="mb-6 rounded-2xl p-6 bg-gradient-to-r from-purple-950/40 via-[#0b101d] to-cyan-950/30 border border-purple-500/20 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <BookOpen className="w-5 h-5" />
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white">
            مكتبة سكربتات وبرومبتات Roblox الجاهزة
          </h2>
        </div>
        <p className="text-sm text-slate-300 max-w-3xl">
          أكواد جاهزة ونماذج حماية مدروسة للنسخ بنقرة واحدة، بالإضافة إلى أوامر ذكاء اصطناعي (Prompt Engineering) متخصصة لبناء ألعاب ضخمة وتطويرها في ثوانٍ.
        </p>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
        
        {/* Search Bar */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            placeholder="ابحث بالاسم، الوصف، أو الـ Tag..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-10 pl-4 py-2 rounded-xl bg-[#0a0e1a] border border-white/10 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-sans"
          />
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {LIBRARY_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  playSound('click');
                  setSelectedCategory(cat.id);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-400/40 shadow-[0_0_12px_-3px_rgba(168,85,247,0.4)]'
                    : 'bg-slate-900/60 border border-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Item Cards & Detail Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Items List (Left/Scrollable) */}
        <div className="lg:col-span-5 space-y-3 max-h-[calc(100vh-20rem)] overflow-y-auto pr-1">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              لم يتم العثور على أي سكربت مطابق لكلمة البحث.
            </div>
          ) : (
            filteredItems.map((item) => {
              const isSelected = activeItem?.id === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    playSound('click');
                    setActiveItem(item);
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-cyan-950/30 border-cyan-400/40 shadow-[0_0_15px_-4px_rgba(34,211,238,0.25)]'
                      : 'bg-[#0a0e1a] border-white/5 hover:border-white/10 hover:bg-slate-900/40'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <h3 className="font-bold text-sm text-slate-100">{item.title}</h3>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-black/40 text-cyan-300 border border-white/5">
                      {item.lang}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 mb-3 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {item.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-white/5"
                      >
                        #{tag}
                      </span>
                    ))}
                    {item.location && (
                      <span className="text-[10px] text-amber-300 font-mono ml-auto">
                        📍 {item.location}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Selected Item Viewer (Right) */}
        <div className="lg:col-span-7">
          {activeItem ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-[#0a0e1a] border border-white/5">
                <div>
                  <h3 className="font-bold text-base text-white">{activeItem.title}</h3>
                  <p className="text-xs text-slate-400 mt-1">{activeItem.description}</p>
                </div>

                {onOpenInWorkspace && (
                  <button
                    onClick={() => onOpenInWorkspace(activeItem)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-cyan-500 to-sky-500 text-slate-950 hover:brightness-110 shadow-md transition-all shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>تعديل السكربت بالذكاء الاصطناعي</span>
                  </button>
                )}
              </div>

              <CodeBlockView
                code={activeItem.content}
                lang={activeItem.lang}
                title={`${activeItem.id}.${activeItem.lang === 'luau' ? 'luau' : 'txt'}`}
                location={activeItem.location}
                onSendToSandbox={onSendToSandbox}
              />
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500">اختر سكربتاً من القائمة لعرضه</div>
          )}
        </div>
      </div>
    </div>
  );
}
