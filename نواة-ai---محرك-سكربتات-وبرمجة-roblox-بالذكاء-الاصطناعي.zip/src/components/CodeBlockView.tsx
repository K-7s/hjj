import React, { useMemo } from 'react';
import { Copy, Check, Download, Play, FileCode, CheckCircle2 } from 'lucide-react';
import { tokenize, type TokenType, LANG_LABELS } from '../lib/highlight';
import type { CodeLang } from '../lib/types';
import { playSound, downloadFile } from '../lib/utils';

interface CodeBlockViewProps {
  code: string;
  lang?: CodeLang;
  title?: string;
  location?: string;
  onSendToSandbox?: (code: string) => void;
}

const TOKEN_COLORS: Record<TokenType, string> = {
  keyword: 'text-cyan-400 font-semibold',
  builtin: 'text-purple-400 font-medium',
  string: 'text-emerald-400',
  number: 'text-amber-300',
  comment: 'text-slate-500 italic',
  function: 'text-sky-300',
  plain: 'text-slate-200',
};

export function CodeBlockView({
  code,
  lang = 'luau',
  title,
  location,
  onSendToSandbox,
}: CodeBlockViewProps) {
  const [copied, setCopied] = React.useState(false);

  const tokens = useMemo(() => tokenize(code, lang), [code, lang]);
  const lines = useMemo(() => code.split('\n'), [code]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    playSound('copy');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const ext = lang === 'luau' || lang === 'lua' ? 'luau' : lang;
    const filename = title ? title.replace(/\s+/g, '_') : `script.${ext}`;
    downloadFile(filename, code, 'text/plain');
    playSound('click');
  };

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-cyan-500/20 bg-[#090d16] shadow-xl group">
      {/* Code Header Bar */}
      <div className="flex flex-wrap items-center justify-between px-4 py-2.5 bg-[#0e1424] border-b border-white/5 gap-2">
        <div className="flex items-center gap-2.5">
          <FileCode className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono font-medium text-slate-200" dir="ltr">
            {title || `script.${lang}`}
          </span>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
            {LANG_LABELS[lang] || lang}
          </span>
          {location && (
            <span className="hidden sm:inline-block text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
              📍 {location}
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5">
          {onSendToSandbox && (
            <button
              onClick={() => {
                playSound('click');
                onSendToSandbox(code);
              }}
              title="اختبار السكربت في المختبر الفاحص"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-purple-300 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/20 transition-all"
            >
              <Play className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">فحص بالمختبر</span>
            </button>
          )}

          <button
            onClick={handleDownload}
            title="تحميل الملف (.luau)"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white border border-white/5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">تحميل</span>
          </button>

          <button
            onClick={handleCopy}
            title="نسخ الكود"
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-all ${
              copied
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30'
            }`}
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
          </button>
        </div>
      </div>

      {/* Code Body with Line Numbers */}
      <div className="relative p-4 font-mono text-xs sm:text-[13px] leading-relaxed overflow-x-auto selection:bg-cyan-500/30" dir="ltr">
        <div className="flex">
          {/* Line Numbers */}
          <div className="select-none text-right pr-4 text-slate-600 border-r border-slate-800 min-w-[2.5rem] font-mono">
            {lines.map((_, i) => (
              <div key={i}>{i + 1}</div>
            ))}
          </div>

          {/* Tokens Content */}
          <div className="pl-4 flex-1 whitespace-pre">
            {tokens.map((token, idx) => (
              <span key={idx} className={TOKEN_COLORS[token.type]}>
                {token.value}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
