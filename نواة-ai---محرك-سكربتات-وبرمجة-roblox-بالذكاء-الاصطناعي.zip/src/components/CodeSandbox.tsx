import React, { useState } from 'react';
import { 
  Code2, 
  Play, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Sparkles, 
  Copy, 
  RefreshCw,
  FileCode,
  Wand2
} from 'lucide-react';
import { playSound } from '../lib/utils';
import { CodeBlockView } from './CodeBlockView';

interface CodeSandboxProps {
  initialCode?: string;
  onAskAIToFix?: (code: string) => void;
}

type LintIssue = {
  line: number;
  severity: 'error' | 'warning' | 'info';
  message: string;
  suggestion?: string;
};

export function CodeSandbox({ initialCode = '', onAskAIToFix }: CodeSandboxProps) {
  const [code, setCode] = useState(
    initialCode ||
`-- اكتب أو الصق سكربت Luau هنا لفحصه واكتشاف الأخطاء
local Players = game:GetService("Players")

local function onPlayerAdded(player)
	print("لاعب دخل اللعبة: " .. player.Name)
	-- استخدام دالة قديمة لتحذير الفاحص
	wait(1)
	local leaderstats = Instance.new("Folder")
	leaderstats.Name = "leaderstats"
	leaderstats.Parent = player
end

Players.PlayerAdded:connect(onPlayerAdded)`
  );

  const [issues, setIssues] = useState<LintIssue[]>([]);
  const [hasScanned, setHasScanned] = useState(false);

  const analyzeCode = () => {
    playSound('click');
    const newIssues: LintIssue[] = [];
    const lines = code.split('\n');

    let blockOpenCount = 0;
    let repeatCount = 0;

    lines.forEach((line, idx) => {
      const lineNum = idx + 1;
      const trimmed = line.trim();

      // Check for legacy wait()
      if (/\bwait\s*\(/.test(trimmed) && !/task\.wait/.test(trimmed)) {
        newIssues.push({
          line: lineNum,
          severity: 'warning',
          message: 'استخدام wait() القديمة يسبب تباطؤ الفريمات (Framerate Throttling).',
          suggestion: 'استبدلها بـ task.wait() المعتمدة في Luau الحديث.',
        });
      }

      // Check for legacy spawn()
      if (/\bspawn\s*\(/.test(trimmed) && !/task\.spawn/.test(trimmed)) {
        newIssues.push({
          line: lineNum,
          severity: 'warning',
          message: 'دالة spawn() غير دقيقة وتتأخر في معالجة المهام.',
          suggestion: 'استخدم task.spawn() للتشغيل الفوري غير المتزامن.',
        });
      }

      // Check for legacy lowercase connect
      if (/:connect\s*\(/.test(trimmed)) {
        newIssues.push({
          line: lineNum,
          severity: 'warning',
          message: 'دالة connect بحرف صغير أصبحت مهملة (Deprecated).',
          suggestion: 'استبدلها بـ :Connect( بالـ C الكبيرة لتجنب مشاكل التوافق.',
        });
      }

      // Check for missing local in variable declarations
      if (/^[a-zA-Z_][a-zA-Z0-9_]*\s*=\s*[^=]/.test(trimmed) && !trimmed.startsWith('local ') && !trimmed.startsWith('self.') && !trimmed.includes(':') && !trimmed.includes('.')) {
        newIssues.push({
          line: lineNum,
          severity: 'info',
          message: 'متغير عام غير محلي (Global Variable Leakage) قد يلوث النطاق العام للذاكرة.',
          suggestion: 'أضف الكلمة المفتاحية local قبل اسم المتغير.',
        });
      }

      // Simple bracket/block counting
      if (/\b(function|then|do)\b/.test(trimmed) && !trimmed.startsWith('--')) {
        blockOpenCount++;
      }
      if (/\brepeat\b/.test(trimmed) && !trimmed.startsWith('--')) {
        repeatCount++;
      }
      if (/\bend\b/.test(trimmed) && !trimmed.startsWith('--')) {
        blockOpenCount--;
      }
      if (/\buntil\b/.test(trimmed) && !trimmed.startsWith('--')) {
        repeatCount--;
      }
    });

    if (blockOpenCount > 0) {
      newIssues.push({
        line: lines.length,
        severity: 'error',
        message: `يوجد نقص في إغلاق العبارات البرمجية (${blockOpenCount} كلمة "end" مفقودة).`,
      });
    } else if (blockOpenCount < 0) {
      newIssues.push({
        line: lines.length,
        severity: 'error',
        message: `يوجد زيادة في كلمات "end" بمقدار ${Math.abs(blockOpenCount)}.`,
      });
    }

    if (repeatCount !== 0) {
      newIssues.push({
        line: lines.length,
        severity: 'error',
        message: 'عدم تطابق بين حلقات repeat و until.',
      });
    }

    setIssues(newIssues);
    setHasScanned(true);

    if (newIssues.length === 0) {
      playSound('success');
    } else {
      playSound('alert');
    }
  };

  const autoFormat = () => {
    playSound('click');
    let indent = 0;
    const lines = code.split('\n');
    const formatted = lines.map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return '';

      // Decrease indent before printing closing words
      if (/^(end|until|else|elseif)/.test(trimmed)) {
        indent = Math.max(0, indent - 1);
      }

      const res = '\t'.repeat(indent) + trimmed;

      // Increase indent after opening words
      if (/\b(then|do|repeat)\s*$/.test(trimmed) || /\bfunction\s*[a-zA-Z0-9_:.]*\s*\(.*\)\s*$/.test(trimmed) || /^(else|elseif)/.test(trimmed)) {
        indent++;
      }

      return res;
    });

    setCode(formatted.join('\n'));
    playSound('success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      
      {/* Header Banner */}
      <div className="mb-6 rounded-2xl p-6 bg-gradient-to-r from-sky-950/40 via-[#0b101d] to-cyan-950/30 border border-sky-500/20 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Code2 className="w-5 h-5" />
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white">
            مختبر فحص وتحليل أكواد Luau
          </h2>
        </div>
        <p className="text-sm text-slate-300 max-w-3xl">
          أداة فحص ثابت (Static Linter) تكتشف الأخطاء الشائعة، الدوال المهملة (Deprecated)، نقص الـ end، وتسريب المتغيرات العامة، مع إمكانية التنسيق التلقائي والتصحيح بالذكاء الاصطناعي.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Editor Area (Left 7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-[#0a0e1a] border border-white/5">
            <div className="flex items-center gap-2">
              <button
                onClick={analyzeCode}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-cyan-500 to-sky-500 text-slate-950 hover:brightness-110 shadow-md transition-all active:scale-95"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>بدء الفحص والتحليل</span>
              </button>

              <button
                onClick={autoFormat}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white border border-white/5 transition-all"
              >
                <Wand2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>تنسيق الكود (Format)</span>
              </button>
            </div>

            {onAskAIToFix && (
              <button
                onClick={() => onAskAIToFix(code)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-purple-300 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/20 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>إصلاح وتطوير بالذكاء</span>
              </button>
            )}
          </div>

          {/* Text Editor */}
          <div className="relative rounded-2xl border border-cyan-500/20 bg-[#090d18] overflow-hidden focus-within:border-cyan-400 shadow-xl">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              rows={18}
              className="w-full bg-transparent p-4 font-mono text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none resize-none leading-relaxed"
              dir="ltr"
              spellCheck={false}
            />
          </div>
        </div>

        {/* Diagnostic Results (Right 5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl p-5 bg-[#0a0e1a] border border-white/5 space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center justify-between">
              <span>نتائج الفحص والتشخيص</span>
              {hasScanned && (
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
                    issues.length === 0
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {issues.length === 0 ? 'كود سليم 100%' : `${issues.length} ملاحظات`}
                </span>
              )}
            </h3>

            {!hasScanned ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                اضغط على زر "بدء الفحص والتحليل" لفحص الكود وكشف أي مشكلات برمجية.
              </div>
            ) : issues.length === 0 ? (
              <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-emerald-300 text-xs space-y-2 text-center">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400" />
                <p className="font-bold text-sm">ممتاز! الكود نظيف ومتوافق تماماً</p>
                <p className="text-slate-400">
                  لم يتم العثور على دوال مهملة أو أخطاء في توازن الأقواس أو تسريب للمتغيرات.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {issues.map((issue, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border text-xs space-y-1 ${
                      issue.severity === 'error'
                        ? 'bg-rose-950/30 border-rose-500/30 text-rose-300'
                        : issue.severity === 'warning'
                        ? 'bg-amber-950/30 border-amber-500/30 text-amber-300'
                        : 'bg-cyan-950/30 border-cyan-500/30 text-cyan-300'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold">
                      <div className="flex items-center gap-1.5">
                        {issue.severity === 'error' ? (
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                        ) : (
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        )}
                        <span>سطر {issue.line}: {issue.message}</span>
                      </div>
                    </div>
                    {issue.suggestion && (
                      <p className="text-slate-400 text-[11px] mt-1 pr-5">
                        💡 نصيحة: {issue.suggestion}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
