import React, { useState } from 'react';
import { SCRIPT_TEMPLATES } from '../lib/luau-generator';
import type { GeneratedFile, ScriptTemplate } from '../lib/types';
import { CodeBlockView } from './CodeBlockView';
import { Wrench, Sliders, CheckCircle, Info, Sparkles } from 'lucide-react';
import { playSound } from '../lib/utils';

interface ScriptGeneratorProps {
  onSendToSandbox: (code: string) => void;
}

export function ScriptGenerator({ onSendToSandbox }: ScriptGeneratorProps) {
  const [selectedTemplateId, setSelectedTemplateId] = useState(SCRIPT_TEMPLATES[0].id);
  const currentTemplate = SCRIPT_TEMPLATES.find((t) => t.id === selectedTemplateId) || SCRIPT_TEMPLATES[0];

  const [fieldValues, setFieldValues] = useState<Record<string, Record<string, any>>>(() => {
    const init: Record<string, Record<string, any>> = {};
    for (const t of SCRIPT_TEMPLATES) {
      init[t.id] = {};
      for (const f of t.fields) {
        init[t.id][f.id] = f.default;
      }
    }
    return init;
  });

  const [activeFileIndex, setActiveFileIndex] = useState(0);

  const currentValues = fieldValues[currentTemplate.id] || {};

  const handleFieldChange = (fieldId: string, val: any) => {
    playSound('click');
    setFieldValues((prev) => ({
      ...prev,
      [currentTemplate.id]: {
        ...prev[currentTemplate.id],
        [fieldId]: val,
      },
    }));
  };

  const generatedFiles: GeneratedFile[] = currentTemplate.build(currentValues);
  const activeFile = generatedFiles[activeFileIndex] || generatedFiles[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      
      {/* Header Banner */}
      <div className="mb-6 rounded-2xl p-6 bg-gradient-to-r from-cyan-950/40 via-[#0b101d] to-purple-950/30 border border-cyan-500/20 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Wrench className="w-5 h-5" />
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white">
            مولّد سكربتات Luau المرئي التفاعلي
          </h2>
        </div>
        <p className="text-sm text-slate-300 max-w-3xl">
          خصّص الإعدادات والمعاملات (الضرر، أوقات التهدئة، مخازن البيانات، السرعة) وشاهد الكود النهائي يتشكل ويتطابق مع معايير Roblox Studio بدون الحاجة لكتابة كود يدوي معقد.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Template Selector & Parameters */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Template Choice List */}
          <div className="rounded-2xl p-4 bg-[#0a0e1a] border border-white/5 space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 px-1">
              اختر النظام البرمجي
            </h3>
            {SCRIPT_TEMPLATES.map((tmpl) => {
              const isSelected = tmpl.id === selectedTemplateId;
              return (
                <button
                  key={tmpl.id}
                  onClick={() => {
                    playSound('click');
                    setSelectedTemplateId(tmpl.id);
                    setActiveFileIndex(0);
                  }}
                  className={`w-full text-right p-3 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-cyan-500/15 border-cyan-400/40 text-cyan-200 shadow-[0_0_15px_-4px_rgba(34,211,238,0.3)]'
                      : 'bg-slate-900/40 border-white/5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="font-bold text-sm text-white mb-0.5">{tmpl.name}</div>
                  <div className="text-xs text-slate-400 line-clamp-1">{tmpl.description}</div>
                </button>
              );
            })}
          </div>

          {/* Parameters Controls */}
          <div className="rounded-2xl p-5 bg-[#0a0e1a] border border-cyan-500/20 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-white/5 text-cyan-300">
              <Sliders className="w-4 h-4" />
              <h3 className="text-sm font-bold">تخصيص معاملات النظام</h3>
            </div>

            <div className="space-y-4">
              {currentTemplate.fields.map((field) => {
                const val = currentValues[field.id] ?? field.default;
                return (
                  <div key={field.id} className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <label className="font-semibold text-slate-300">{field.label}</label>
                      {field.type === 'number' && (
                        <span className="font-mono text-cyan-400 font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-500/30">
                          {val}
                        </span>
                      )}
                    </div>

                    {field.type === 'number' ? (
                      <input
                        type="range"
                        min={field.min ?? 0}
                        max={field.max ?? 500}
                        step={field.step ?? 1}
                        value={val}
                        onChange={(e) => handleFieldChange(field.id, Number(e.target.value))}
                        className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
                      />
                    ) : (
                      <input
                        type="text"
                        value={val}
                        onChange={(e) => handleFieldChange(field.id, e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs text-slate-100 focus:outline-none focus:border-cyan-400 font-mono"
                        dir="ltr"
                      />
                    )}

                    {field.hint && (
                      <p className="text-[11px] text-slate-500">{field.hint}</p>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Setup Guidelines */}
            <div className="mt-4 pt-3 border-t border-white/5 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300">
                <Info className="w-3.5 h-3.5" />
                <span>تعليمات التركيب في الاستوديو:</span>
              </div>
              <ul className="space-y-1 text-xs text-slate-400 list-disc list-inside">
                {currentTemplate.setup.map((s, idx) => (
                  <li key={idx}>{s}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right Column: Generated Code Output */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* File Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {generatedFiles.map((f, idx) => {
              const isActive = activeFileIndex === idx;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    playSound('click');
                    setActiveFileIndex(idx);
                  }}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-mono font-medium transition-all ${
                    isActive
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_15px_-4px_rgba(34,211,238,0.3)]'
                      : 'bg-[#0a0e1a] text-slate-400 hover:text-slate-200 border border-white/5'
                  }`}
                  dir="ltr"
                >
                  <span>{f.name}.luau</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/40 text-slate-400">
                    {f.location}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active File Code Viewer */}
          {activeFile && (
            <CodeBlockView
              code={activeFile.code}
              lang="luau"
              title={`${activeFile.name}.luau`}
              location={activeFile.location}
              onSendToSandbox={onSendToSandbox}
            />
          )}
        </div>
      </div>
    </div>
  );
}
