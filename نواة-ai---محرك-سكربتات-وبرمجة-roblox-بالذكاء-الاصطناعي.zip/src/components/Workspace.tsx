import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Trash2, 
  Cpu, 
  ShieldAlert, 
  Wrench, 
  Palette, 
  Sparkles, 
  Zap, 
  CornerDownLeft, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw,
  Terminal,
  Activity,
  ArrowDown
} from 'lucide-react';
import { ENGINES, getEngine } from '../lib/engines';
import type { Block, ChatMessage, EngineId } from '../lib/types';
import { streamGeminiChat, type BenchmarkStats } from '../lib/gemini-client';
import { CodeBlockView } from './CodeBlockView';
import { playSound } from '../lib/utils';

interface WorkspaceProps {
  onSendToSandbox: (code: string) => void;
}

const ENGINE_ICONS: Record<EngineId, React.ComponentType<{ className?: string }>> = {
  architect: Cpu,
  security: ShieldAlert,
  debugger: Wrench,
  ui: Palette,
  prompt: Sparkles,
  luau_classic: Zap,
};

export function Workspace({ onSendToSandbox }: WorkspaceProps) {
  const [selectedEngineId, setSelectedEngineId] = useState<EngineId>('architect');
  const [modelMode, setModelMode] = useState<'gemini' | 'local'>('gemini');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      engineId: 'architect',
      content: 'أهلاً بك في "نواة AI" المطورة! أنا هنا لمساعدتك في بناء وتطوير أي نظام تريده في Roblox Studio بلغة Luau الحديثة، فحص السكربتات وتصحيح الأخطاء، وسد ثغرات الحماية. تم تفعيل نموذج Google Gemini 3.8 Flash المجاني الفائق للتعامل مع الضغط العالي والمهام المعقدة!',
      blocks: [
        {
          kind: 'note',
          tone: 'success',
          content: '⚡ جاهز للعمل: اختر المحرك المناسب، أو اختر أحد الاقتراحات السريعة أدناه للبدء فوراً!',
        },
      ],
      modelUsed: 'gemini-3.8-flash',
    },
  ]);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [latestStats, setLatestStats] = useState<BenchmarkStats | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const currentEngine = getEngine(selectedEngineId);
  const IconComponent = ENGINE_ICONS[selectedEngineId] || Cpu;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isGenerating]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = (customPrompt || input).trim();
    if (!textToSend || isGenerating) return;

    setInput('');
    playSound('send');

    const userMsgId = 'msg-' + Date.now();
    const assistantMsgId = 'asst-' + (Date.now() + 1);

    const userMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      engineId: selectedEngineId,
      content: textToSend,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    const initialAssistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      engineId: selectedEngineId,
      content: '',
      status: 'thinking',
      blocks: [],
      modelUsed: modelMode === 'gemini' ? 'gemini-3.8-flash' : 'local-turbo',
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg, initialAssistantMsg]);
    setIsGenerating(true);

    if (modelMode === 'local' || selectedEngineId === 'luau_classic') {
      // Instant local engine
      setTimeout(() => {
        const localResult = currentEngine.runLocal
          ? currentEngine.runLocal(textToSend, {})
          : getEngine('luau_classic').runLocal!(textToSend, {});
        
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'done',
                  blocks: localResult.blocks,
                  content: textToSend,
                }
              : m
          )
        );
        setIsGenerating(false);
        playSound('success');
      }, 350);
      return;
    }

    // Call Real Gemini 3.8 Flash Stream
    await streamGeminiChat({
      prompt: textToSend,
      engineId: selectedEngineId,
      systemInstruction: currentEngine.systemPrompt,
      history: messages,
      model: 'gemini-3.8-flash',
      onChunk: (accumulated, stats) => {
        setLatestStats(stats);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'streaming',
                  content: accumulated,
                }
              : m
          )
        );
      },
      onDone: (finalBlocks, stats) => {
        setLatestStats(stats);
        setIsGenerating(false);
        playSound('success');
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'done',
                  blocks: finalBlocks,
                  latencyMs: stats.latencyMs,
                  modelUsed: stats.model,
                }
              : m
          )
        );
      },
      onError: (errorMsg) => {
        setIsGenerating(false);
        playSound('alert');
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'error',
                  content: errorMsg,
                }
              : m
          )
        );
      },
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    playSound('click');
    setMessages([
      {
        id: 'msg-cleared',
        role: 'assistant',
        engineId: selectedEngineId,
        content: 'تم تفريغ المحادثة. جاهز لأي طلب برمجي جديد!',
        blocks: [],
      },
    ]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex flex-col h-[calc(100vh-5rem)]">
      
      {/* Top Engine & Mode Switcher Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/5">
        
        {/* Engine Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
          {ENGINES.map((engine) => {
            const EngineIcon = ENGINE_ICONS[engine.id] || Cpu;
            const isSelected = selectedEngineId === engine.id;
            return (
              <button
                key={engine.id}
                onClick={() => {
                  playSound('click');
                  setSelectedEngineId(engine.id);
                }}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 shadow-[0_0_12px_-3px_rgba(34,211,238,0.3)]'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-900/60 border border-white/5 hover:bg-slate-800'
                }`}
              >
                <EngineIcon className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{engine.name}</span>
                <span className="text-[10px] px-1 rounded bg-black/40 text-slate-400">
                  {engine.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Model Mode Toggle & Metrics */}
        <div className="flex items-center gap-3">
          {latestStats && (
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-md bg-slate-900 border border-cyan-500/20 text-[11px] text-cyan-300 font-mono">
              <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>{latestStats.latencyMs}ms</span>
              <span className="text-slate-600">|</span>
              <span>{latestStats.tokensPerSecond} TPS</span>
            </div>
          )}

          <div className="flex items-center p-0.5 rounded-lg bg-slate-900 border border-white/10 text-xs">
            <button
              onClick={() => {
                playSound('click');
                setModelMode('gemini');
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all ${
                modelMode === 'gemini'
                  ? 'bg-cyan-500/20 text-cyan-300 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span>Gemini 3.8 AI</span>
            </button>
            <button
              onClick={() => {
                playSound('click');
                setModelMode('local');
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all ${
                modelMode === 'local'
                  ? 'bg-purple-500/20 text-purple-300 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              <span>Turbo محلي</span>
            </button>
          </div>

          <button
            onClick={clearChat}
            title="تفريغ المحادثة"
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition-all"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Stream Container */}
      <div className="flex-1 overflow-y-auto py-6 space-y-6 pr-1 pl-1">
        {messages.map((message) => {
          const isUser = message.role === 'user';
          return (
            <div
              key={message.id}
              className={`flex gap-3 sm:gap-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Role Avatar */}
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border shadow-md ${
                  isUser
                    ? 'bg-cyan-950/80 border-cyan-500/40 text-cyan-300'
                    : 'bg-[#0f1424] border-purple-500/40 text-purple-300'
                }`}
              >
                {isUser ? <Terminal className="w-4 h-4" /> : <IconComponent className="w-4 h-4" />}
              </div>

              {/* Message Content Bubble */}
              <div
                className={`max-w-3xl rounded-2xl p-4 sm:p-5 border shadow-lg ${
                  isUser
                    ? 'bg-gradient-to-br from-cyan-950/60 to-slate-900/90 border-cyan-500/30 text-cyan-50'
                    : 'bg-[#0a0e1a]/90 border-white/10 text-slate-200'
                }`}
              >
                {/* Header Info */}
                <div className="flex items-center justify-between gap-4 mb-2 pb-1.5 border-b border-white/5 text-[11px] text-slate-400 font-medium">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-300">
                      {isUser ? 'أنت (المطور)' : currentEngine.name}
                    </span>
                    {!isUser && message.modelUsed && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 border border-cyan-500/30 text-cyan-300 font-mono">
                        {message.modelUsed}
                      </span>
                    )}
                  </div>
                  {message.latencyMs && (
                    <span className="text-[10px] text-slate-500 font-mono">
                      {message.latencyMs}ms
                    </span>
                  )}
                </div>

                {/* Thinking / Streaming Status */}
                {message.status === 'thinking' && (
                  <div className="flex items-center gap-2 py-3 text-cyan-300 text-xs">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" />
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.15s]" />
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.3s]" />
                    </div>
                    <span>جاري التفكير وصياغة الكود بأعلى كفاءة عبر Gemini 3.8 Flash...</span>
                  </div>
                )}

                {/* Raw Content / Text */}
                {message.content && (!message.blocks || message.blocks.length === 0) && (
                  <div className="whitespace-pre-wrap leading-relaxed text-sm">
                    {message.content}
                    {message.status === 'streaming' && (
                      <span className="inline-block w-2 h-4 bg-cyan-400 ml-1 animate-pulse align-middle" />
                    )}
                  </div>
                )}

                {/* Structured Blocks (Headings, Text, CodeBlocks, Notes) */}
                {message.blocks && message.blocks.length > 0 && (
                  <div className="space-y-3 mt-2">
                    {message.blocks.map((block, idx) => {
                      if (block.kind === 'heading') {
                        return (
                          <h3
                            key={idx}
                            className="font-bold text-base sm:text-lg text-cyan-200 mt-2 mb-1 flex items-center gap-2"
                          >
                            <span className="w-1.5 h-4 rounded-full bg-cyan-400 inline-block" />
                            {block.content}
                          </h3>
                        );
                      }
                      if (block.kind === 'text') {
                        return (
                          <p key={idx} className="text-sm leading-relaxed text-slate-300 whitespace-pre-wrap">
                            {block.content}
                          </p>
                        );
                      }
                      if (block.kind === 'note') {
                        return (
                          <div
                            key={idx}
                            className={`p-3 rounded-xl border text-xs sm:text-sm flex items-start gap-2.5 my-2 ${
                              block.tone === 'success'
                                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                                : block.tone === 'warn'
                                ? 'bg-amber-950/40 border-amber-500/30 text-amber-300'
                                : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300'
                            }`}
                          >
                            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                            <span>{block.content}</span>
                          </div>
                        );
                      }
                      if (block.kind === 'list') {
                        return (
                          <ul key={idx} className="list-disc list-inside space-y-1 text-sm text-slate-300 my-2">
                            {block.items.map((item, itemIdx) => (
                              <li key={itemIdx}>{item}</li>
                            ))}
                          </ul>
                        );
                      }
                      if (block.kind === 'code') {
                        return (
                          <CodeBlockView
                            key={idx}
                            code={block.content}
                            lang={block.lang}
                            title={block.title}
                            location={block.location}
                            onSendToSandbox={onSendToSandbox}
                          />
                        );
                      }
                      return null;
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Chips */}
      <div className="py-2 flex items-center gap-2 overflow-x-auto scrollbar-none">
        <span className="text-[11px] font-semibold text-slate-500 shrink-0">اقتراحات:</span>
        {currentEngine.suggestions.map((suggestion, idx) => (
          <button
            key={idx}
            disabled={isGenerating}
            onClick={() => handleSend(suggestion)}
            className="text-xs px-3 py-1 rounded-full bg-slate-900 hover:bg-cyan-950/60 text-slate-300 hover:text-cyan-300 border border-white/5 hover:border-cyan-500/30 transition-all shrink-0 text-right"
          >
            {suggestion}
          </button>
        ))}
      </div>

      {/* Input Composer */}
      <div className="relative mt-2 rounded-2xl border border-cyan-500/30 bg-[#090d18] shadow-[0_0_30px_-10px_rgba(34,211,238,0.2)] focus-within:border-cyan-400 focus-within:shadow-[0_0_30px_-5px_rgba(34,211,238,0.35)] transition-all">
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={currentEngine.placeholder}
          rows={3}
          disabled={isGenerating}
          className="w-full bg-transparent p-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none resize-none font-sans"
        />

        <div className="flex items-center justify-between px-4 pb-3 pt-1 border-t border-white/5">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="hidden sm:inline">اضغط</span>
            <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-cyan-300">
              Ctrl + Enter
            </kbd>
            <span className="hidden sm:inline">للإرسال السريع</span>
          </div>

          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isGenerating}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
              !input.trim() || isGenerating
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
                : 'bg-gradient-to-r from-cyan-500 to-sky-500 text-slate-950 hover:brightness-110 shadow-[0_0_20px_-3px_rgba(34,211,238,0.5)] active:scale-95'
            }`}
          >
            <span>{isGenerating ? 'جاري التوليد...' : 'إرسال واستخراج الكود'}</span>
            <Send className="w-3.5 h-3.5 rotate-180" />
          </button>
        </div>
      </div>
    </div>
  );
}
