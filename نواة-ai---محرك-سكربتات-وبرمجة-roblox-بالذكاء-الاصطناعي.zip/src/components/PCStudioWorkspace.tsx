import React, { useState, useRef, useEffect } from 'react';
import { 
  Cpu, 
  ShieldAlert, 
  Wrench, 
  Palette, 
  Sparkles, 
  Zap, 
  Send, 
  Trash2, 
  Folder, 
  FolderOpen, 
  FileCode, 
  Play, 
  Copy, 
  Check, 
  Download, 
  Wand2, 
  ChevronRight, 
  ChevronDown, 
  Maximize2, 
  Minimize2, 
  Activity, 
  Layers, 
  Terminal, 
  Code2, 
  ExternalLink,
  Sliders,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { ENGINES, getEngine } from '../lib/engines';
import type { Block, ChatMessage, CodeLang, EngineId } from '../lib/types';
import { streamGeminiChat, type BenchmarkStats } from '../lib/gemini-client';
import { CodeBlockView } from './CodeBlockView';
import { playSound, downloadFile } from '../lib/utils';
import { tokenize, type TokenType } from '../lib/highlight';

interface PCStudioWorkspaceProps {
  onSendToSandbox: (code: string) => void;
}

const ENGINE_ICONS: Record<EngineId, React.ComponentType<{ className?: string }>> = {
  architect: Cpu,
  security: ShieldAlert,
  debugger: Wrench,
  ui: Palette,
  prompt: Sparkles,
  luau_classic: Zap,
};

// Open file item in the PC Studio IDE
type OpenScriptFile = {
  id: string;
  name: string;
  location: string;
  scriptType: 'Script' | 'LocalScript' | 'ModuleScript';
  code: string;
  isModified?: boolean;
};

// Preset default files in the Roblox Explorer tree
const INITIAL_EXPLORER_SCRIPTS: OpenScriptFile[] = [
  {
    id: 'weapon-shop-server',
    name: 'WeaponShopServer.luau',
    location: 'ServerScriptService',
    scriptType: 'Script',
    code: `--[[
    WeaponShopServer.luau
    المكان: ServerScriptService (Script)
    الوظيفة: معالجة شراء وترقية الأسلحة مع التحقق المالي على الخادم
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local shopEvents = ReplicatedStorage:WaitForChild("ShopEvents")
local buyRemote = shopEvents:WaitForChild("BuyWeapon") :: RemoteFunction
local upgradeRemote = shopEvents:WaitForChild("UpgradeWeapon") :: RemoteFunction

local WEAPON_CONFIG = {
    ["LaserRifle"] = { BasePrice = 500, Multiplier = 1.5, MaxLevel = 5 },
    ["PlasmaSword"] = { BasePrice = 350, Multiplier = 1.4, MaxLevel = 5 },
}

local playerWeapons = {}

buyRemote.OnServerInvoke = function(player: Player, weaponId: string)
    if typeof(weaponId) ~= "string" or not WEAPON_CONFIG[weaponId] then
        return { success = false, message = "سلاح غير صالح" }
    end

    local leaderstats = player:FindFirstChild("leaderstats")
    local coins = leaderstats and leaderstats:FindFirstChild("Coins") :: IntValue?
    if not coins or coins.Value < WEAPON_CONFIG[weaponId].BasePrice then
        return { success = false, message = "رصيدك غير كافٍ!" }
    end

    coins.Value -= WEAPON_CONFIG[weaponId].BasePrice
    if not playerWeapons[player] then playerWeapons[player] = {} end
    playerWeapons[player][weaponId] = 1

    return { success = true, level = 1, remaining = coins.Value }
end`,
  },
  {
    id: 'weapon-shop-client',
    name: 'WeaponShopClient.luau',
    location: 'StarterPlayerScripts',
    scriptType: 'LocalScript',
    code: `--[[
    WeaponShopClient.luau
    المكان: StarterPlayer/StarterPlayerScripts (LocalScript)
    الوظيفة: تشغيل الأصوات واستدعاء الخادم وتحديث واجهة الشراء
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundService = game:GetService("SoundService")

local shopEvents = ReplicatedStorage:WaitForChild("ShopEvents")
local buyRemote = shopEvents:WaitForChild("BuyWeapon") :: RemoteFunction

local function playSound(soundId: string)
    local s = Instance.new("Sound")
    s.SoundId = "rbxassetid://" .. soundId
    s.Volume = 0.6
    s.Parent = SoundService
    s:Play()
    s.Ended:Connect(function() s:Destroy() end)
end

local function buyItem(id: string)
    local res = buyRemote:InvokeServer(id)
    if res.success then
        playSound("5153734608") -- صوت الشراء الناجح
        print("تم الشراء بنجاح!")
    else
        playSound("4590662766") -- صوت الفشل
        warn("فشل الشراء: " .. res.message)
    end
end`,
  },
  {
    id: 'anti-exploit-server',
    name: 'ServerAntiCheat.luau',
    location: 'ServerScriptService',
    scriptType: 'Script',
    code: `--[[
    ServerAntiCheat.luau
    المكان: ServerScriptService
    الوظيفة: مراقبة السرعة الحقيقية ومنع الهاكات
]]

local Players = game:GetService("Players")
local MAX_SPEED = 24

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(char)
        local root = char:WaitForChild("HumanoidRootPart") :: BasePart
        local lastPos = root.Position
        local lastTime = os.clock()

        while char.Parent do
            task.wait(0.5)
            local now = os.clock()
            local dt = now - lastTime
            local dist = (root.Position - lastPos).Magnitude
            local speed = dist / dt

            if speed > (MAX_SPEED * 1.5) then
                warn(string.format("تحذير: %s تجاوز السرعة المسموحة! (%.1f)", player.Name, speed))
                root.CFrame = CFrame.new(lastPos)
            else
                lastPos = root.Position
            end
            lastTime = now
        end
    end)
end)`,
  },
];

export function PCStudioWorkspace({ onSendToSandbox }: PCStudioWorkspaceProps) {
  const [selectedEngineId, setSelectedEngineId] = useState<EngineId>('architect');
  const [openFiles, setOpenFiles] = useState<OpenScriptFile[]>(INITIAL_EXPLORER_SCRIPTS);
  const [activeFileId, setActiveFileId] = useState<string>(INITIAL_EXPLORER_SCRIPTS[0].id);
  const [editorCode, setEditorCode] = useState<string>(INITIAL_EXPLORER_SCRIPTS[0].code);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-pc',
      role: 'assistant',
      engineId: 'architect',
      content: 'مرحباً بك في استوديو "نواة AI" المخصص للـ PC! تم تصميم هذه الواجهة بنمط استوديو كامل (Roblox Studio / IDE): شجرة ملفات Roblox على اليمين، محادثة الذكاء بالوسط، ومحرر الأكواد المتقدم على اليسار.',
      blocks: [
        {
          kind: 'note',
          tone: 'success',
          content: '⚡ تم تفعيل معمارية Gemini 3.8 Flash مع الاستجابة الفورية الصامدة للضغط. اختر أو اطلب أي سكربت ليفتح مباشرة في الاستوديو!',
        },
      ],
      modelUsed: 'gemini-3.8-flash',
    },
  ]);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [latestStats, setLatestStats] = useState<BenchmarkStats | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showExplorer, setShowExplorer] = useState(true);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const currentEngine = getEngine(selectedEngineId);
  const IconComponent = ENGINE_ICONS[selectedEngineId] || Cpu;

  const activeFile = openFiles.find((f) => f.id === activeFileId) || openFiles[0];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGenerating]);

  // Sync editor when active file changes
  const switchFile = (file: OpenScriptFile) => {
    playSound('click');
    if (!openFiles.some((f) => f.id === file.id)) {
      setOpenFiles((prev) => [...prev, file]);
    }
    setActiveFileId(file.id);
    setEditorCode(file.code);
  };

  const closeFile = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('click');
    if (openFiles.length <= 1) return;
    const remaining = openFiles.filter((f) => f.id !== id);
    setOpenFiles(remaining);
    if (activeFileId === id) {
      setActiveFileId(remaining[0].id);
      setEditorCode(remaining[0].code);
    }
  };

  const loadGeneratedCodeToStudio = (title: string, code: string, location?: string) => {
    playSound('success');
    const fileId = 'gen-' + Date.now();
    const newFile: OpenScriptFile = {
      id: fileId,
      name: title || 'GeneratedScript.luau',
      location: location || 'ServerScriptService',
      scriptType: title?.toLowerCase().includes('client') ? 'LocalScript' : 'Script',
      code,
    };
    setOpenFiles((prev) => [newFile, ...prev]);
    setActiveFileId(fileId);
    setEditorCode(code);
  };

  const handleSend = async (customPrompt?: string) => {
    const textToSend = (customPrompt || input).trim();
    if (!textToSend || isGenerating) return;

    setInput('');
    playSound('send');

    const userMsgId = 'msg-' + Date.now();
    const assistantMsgId = 'asst-' + (Date.now() + 1);

    const userMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      engineId: selectedEngineId,
      content: textToSend,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    const initialAssistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      engineId: selectedEngineId,
      content: '',
      status: 'thinking',
      blocks: [],
      modelUsed: 'gemini-3.8-flash',
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg, initialAssistantMsg]);
    setIsGenerating(true);

    await streamGeminiChat({
      prompt: textToSend,
      engineId: selectedEngineId,
      systemInstruction: currentEngine.systemPrompt,
      history: messages,
      model: 'gemini-3.8-flash',
      onChunk: (accumulated, stats) => {
        setLatestStats(stats);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'streaming',
                  content: accumulated,
                }
              : m
          )
        );
      },
      onDone: (finalBlocks, stats, rawText) => {
        setLatestStats(stats);
        setIsGenerating(false);
        playSound('success');

        // Extract first generated code block and open directly into PC Studio editor!
        const codeBlock = finalBlocks.find((b) => b.kind === 'code');
        if (codeBlock && codeBlock.kind === 'code') {
          loadGeneratedCodeToStudio(codeBlock.title || 'GeneratedScript.luau', codeBlock.content, codeBlock.location);
        }

        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'done',
                  blocks: finalBlocks,
                  content: rawText,
                  latencyMs: stats.latencyMs,
                  modelUsed: stats.model,
                }
              : m
          )
        );
      },
      onError: (errorMsg) => {
        setIsGenerating(false);
        playSound('alert');
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'error',
                  content: errorMsg,
                }
              : m
          )
        );
      },
    });
  };

  const handleCopyEditorCode = () => {
    navigator.clipboard.writeText(editorCode);
    setCopiedCode(true);
    playSound('copy');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadActiveFile = () => {
    downloadFile(activeFile.name, editorCode, 'text/plain');
    playSound('click');
  };

  const lines = editorCode.split('\n');

  return (
    <div className="w-full h-[calc(100vh-4rem)] flex flex-col bg-[#07090e] overflow-hidden select-none">
      
      {/* Top PC Studio Quick Action Header */}
      <div className="h-10 border-b border-white/5 bg-[#090d18] px-4 flex items-center justify-between text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowExplorer(!showExplorer)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded hover:bg-slate-800 transition-all ${
              showExplorer ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-400'
            }`}
            title="إظهار / إخفاء شجرة روبلوكس"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="font-semibold">مستكشف روبلوكس (Explorer)</span>
          </button>

          <span className="text-slate-700">|</span>

          {/* Engine Selector */}
          <div className="flex items-center gap-1">
            {ENGINES.slice(0, 4).map((eng) => {
              const Icon = ENGINE_ICONS[eng.id];
              const isSelected = selectedEngineId === eng.id;
              return (
                <button
                  key={eng.id}
                  onClick={() => {
                    playSound('click');
                    setSelectedEngineId(eng.id);
                  }}
                  className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-medium transition-all ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3 h-3" />
                  <span>{eng.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Metrics & Quick Stats */}
        <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
          {latestStats && (
            <div className="flex items-center gap-2 text-cyan-300">
              <Activity className="w-3 h-3 text-cyan-400 animate-pulse" />
              <span>{latestStats.latencyMs}ms</span>
              <span className="text-slate-700">•</span>
              <span>{latestStats.tokensPerSecond} TPS</span>
            </div>
          )}
          <div className="flex items-center gap-1 text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>Roblox Luau PC Mode</span>
          </div>
        </div>
      </div>

      {/* Main 3-Column PC Studio Split Layout */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Column 1: Roblox Explorer Tree (Right side in RTL) */}
        {showExplorer && (
          <div className="w-64 border-l border-white/5 bg-[#090d18] flex flex-col shrink-0">
            <div className="p-3 border-b border-white/5 flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>شجرة المشروع (Hierarchy)</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Roblox Studio</span>
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-1 text-xs font-mono text-slate-400" dir="ltr">
              
              {/* Workspace Folder */}
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 px-2 py-1 text-slate-300 hover:bg-slate-800/40 rounded cursor-pointer">
                  <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-semibold">Workspace</span>
                </div>
                <div className="pl-4 space-y-0.5">
                  <div className="flex items-center gap-1.5 px-2 py-0.5 text-slate-500 hover:text-slate-300 cursor-pointer">
                    <span className="w-2 h-2 rounded-sm bg-purple-500/40" />
                    <span>ArenaSpawns</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-0.5 text-slate-500 hover:text-slate-300 cursor-pointer">
                    <span className="w-2 h-2 rounded-sm bg-cyan-500/40" />
                    <span>KillBrickPart</span>
                  </div>
                </div>
              </div>

              {/* ServerScriptService Folder */}
              <div className="space-y-0.5 mt-2">
                <div className="flex items-center gap-1.5 px-2 py-1 text-slate-300 hover:bg-slate-800/40 rounded cursor-pointer">
                  <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-semibold text-cyan-300">ServerScriptService</span>
                </div>
                <div className="pl-4 space-y-0.5">
                  {openFiles
                    .filter((f) => f.location.includes('ServerScriptService'))
                    .map((file) => (
                      <div
                        key={file.id}
                        onClick={() => switchFile(file)}
                        className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-all ${
                          activeFileId === file.id
                            ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 truncate">
                          <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                          <span className="truncate">{file.name}</span>
                        </div>
                        <span className="text-[9px] px-1 bg-black/40 rounded text-slate-400">S</span>
                      </div>
                    ))}
                </div>
              </div>

              {/* ReplicatedStorage Folder */}
              <div className="space-y-0.5 mt-2">
                <div className="flex items-center gap-1.5 px-2 py-1 text-slate-300 hover:bg-slate-800/40 rounded cursor-pointer">
                  <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-semibold text-purple-300">ReplicatedStorage</span>
                </div>
                <div className="pl-4 space-y-0.5 text-slate-500">
                  <div className="flex items-center gap-1.5 px-2 py-0.5 hover:text-slate-300 cursor-pointer">
                    <Zap className="w-3 h-3 text-purple-400" />
                    <span>ShopEvents (Folder)</span>
                  </div>
                </div>
              </div>

              {/* StarterPlayerScripts Folder */}
              <div className="space-y-0.5 mt-2">
                <div className="flex items-center gap-1.5 px-2 py-1 text-slate-300 hover:bg-slate-800/40 rounded cursor-pointer">
                  <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-semibold text-emerald-300">StarterPlayerScripts</span>
                </div>
                <div className="pl-4 space-y-0.5">
                  {openFiles
                    .filter((f) => f.location.includes('StarterPlayer'))
                    .map((file) => (
                      <div
                        key={file.id}
                        onClick={() => switchFile(file)}
                        className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-all ${
                          activeFileId === file.id
                            ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 truncate">
                          <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="truncate">{file.name}</span>
                        </div>
                        <span className="text-[9px] px-1 bg-black/40 rounded text-slate-400">LS</span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Column 2: AI Prompt & Chat Terminal (Middle) */}
        <div className="w-[420px] lg:w-[460px] border-l border-white/5 bg-[#080b14] flex flex-col shrink-0">
          
          {/* Chat Header */}
          <div className="p-3 border-b border-white/5 flex items-center justify-between text-xs bg-[#0b0f1d]">
            <div className="flex items-center gap-2">
              <IconComponent className="w-4 h-4 text-cyan-400" />
              <span className="font-bold text-slate-200">{currentEngine.name}</span>
            </div>
            <button
              onClick={() => {
                playSound('click');
                setMessages([
                  {
                    id: 'cleared',
                    role: 'assistant',
                    engineId: selectedEngineId,
                    content: 'تم تفريغ المحادثة. جاهز لأي طلب برمجي جديد!',
                  },
                ]);
              }}
              title="تفريغ المحادثة"
              className="p-1 hover:text-rose-400 transition-all text-slate-500"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => {
              const isUser = message.role === 'user';
              return (
                <div key={message.id} className={`space-y-1.5 ${isUser ? 'mr-4' : 'ml-1'}`}>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                    <span className={isUser ? 'text-cyan-400 font-bold' : 'text-purple-300 font-bold'}>
                      {isUser ? '👤 أنت' : `🤖 ${currentEngine.name}`}
                    </span>
                    {message.latencyMs && (
                      <span className="text-[10px] font-mono text-slate-500">{message.latencyMs}ms</span>
                    )}
                  </div>

                  <div
                    className={`p-3.5 rounded-xl border text-xs leading-relaxed select-text ${
                      isUser
                        ? 'bg-cyan-950/40 border-cyan-500/30 text-cyan-100'
                        : 'bg-[#0d1222] border-white/10 text-slate-200'
                    }`}
                  >
                    {message.status === 'thinking' && (
                      <div className="flex items-center gap-2 py-2 text-cyan-400">
                        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                        <span>جاري هندسة الكود في الاستوديو...</span>
                      </div>
                    )}

                    {message.content && (!message.blocks || message.blocks.length === 0) && (
                      <div className="whitespace-pre-wrap">{message.content}</div>
                    )}

                    {message.blocks && message.blocks.length > 0 && (
                      <div className="space-y-2 mt-1">
                        {message.blocks.map((b, idx) => {
                          if (b.kind === 'heading') {
                            return (
                              <h4 key={idx} className="font-bold text-sm text-cyan-300 mt-2">
                                {b.content}
                              </h4>
                            );
                          }
                          if (b.kind === 'text') {
                            return <p key={idx} className="text-slate-300">{b.content}</p>;
                          }
                          if (b.kind === 'note') {
                            return (
                              <div key={idx} className="p-2 rounded bg-cyan-950/40 border border-cyan-500/20 text-cyan-300 text-[11px]">
                                {b.content}
                              </div>
                            );
                          }
                          if (b.kind === 'code') {
                            return (
                              <div key={idx} className="my-2 p-2.5 rounded-lg bg-black/60 border border-cyan-500/20">
                                <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-white/5 text-[11px] font-mono">
                                  <span className="text-cyan-400 truncate">{b.title || 'Script.luau'}</span>
                                  <button
                                    onClick={() => loadGeneratedCodeToStudio(b.title || 'Script.luau', b.content, b.location)}
                                    className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30 font-sans"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                    <span>فتح في المحرر</span>
                                  </button>
                                </div>
                                <pre className="text-[11px] font-mono text-slate-300 line-clamp-4 overflow-hidden" dir="ltr">
                                  {b.content.slice(0, 180)}...
                                </pre>
                              </div>
                            );
                          }
                          return null;
                        })}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Suggestions Chips */}
          <div className="p-2 border-t border-white/5 flex items-center gap-1.5 overflow-x-auto bg-[#0a0e1c] scrollbar-none">
            {currentEngine.suggestions.slice(0, 3).map((s, idx) => (
              <button
                key={idx}
                disabled={isGenerating}
                onClick={() => handleSend(s)}
                className="text-[11px] px-2.5 py-1 rounded bg-slate-900 hover:bg-cyan-950/60 text-slate-300 hover:text-cyan-300 border border-white/5 hover:border-cyan-500/30 transition-all shrink-0"
              >
                {s.slice(0, 32)}...
              </button>
            ))}
          </div>

          {/* Prompt Composer */}
          <div className="p-3 border-t border-white/5 bg-[#090d18]">
            <div className="relative rounded-xl border border-cyan-500/30 bg-[#0d1222] focus-within:border-cyan-400 shadow-lg">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                rows={3}
                disabled={isGenerating}
                placeholder={currentEngine.placeholder}
                className="w-full bg-transparent p-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none resize-none font-sans"
              />

              <div className="flex items-center justify-between px-3 py-2 border-t border-white/5 text-[11px]">
                <span className="text-slate-500 font-mono">
                  <kbd className="px-1 py-0.5 rounded bg-slate-800 text-cyan-400">Ctrl+Enter</kbd>
                </span>

                <button
                  onClick={() => handleSend()}
                  disabled={!input.trim() || isGenerating}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs transition-all ${
                    !input.trim() || isGenerating
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-cyan-500 to-sky-500 text-slate-950 hover:brightness-110 shadow-md active:scale-95'
                  }`}
                >
                  <span>{isGenerating ? 'جاري التوليد...' : 'توليد الكود'}</span>
                  <Send className="w-3 h-3 rotate-180" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Column 3: Full-Fledged PC Code Studio IDE (Left side in RTL) */}
        <div className="flex-1 flex flex-col bg-[#07090e] overflow-hidden">
          
          {/* File Tabs Bar */}
          <div className="h-10 border-b border-white/5 bg-[#090d18] flex items-center px-2 gap-1 overflow-x-auto select-none">
            {openFiles.map((file) => {
              const isActive = activeFileId === file.id;
              return (
                <div
                  key={file.id}
                  onClick={() => switchFile(file)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs font-mono cursor-pointer border-t-2 transition-all ${
                    isActive
                      ? 'bg-[#0e1424] text-cyan-300 border-cyan-400 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850 border-transparent'
                  }`}
                  dir="ltr"
                >
                  <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{file.name}</span>
                  {openFiles.length > 1 && (
                    <button
                      onClick={(e) => closeFile(file.id, e)}
                      className="text-slate-500 hover:text-rose-400 p-0.5 rounded"
                    >
                      ×
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Studio IDE Toolbar */}
          <div className="px-4 py-2 border-b border-white/5 bg-[#0a0e1c] flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 font-mono text-slate-400" dir="ltr">
              <span className="text-amber-400">game</span>
              <span>&gt;</span>
              <span className="text-purple-300">{activeFile.location}</span>
              <span>&gt;</span>
              <span className="text-cyan-300 font-bold">{activeFile.name}</span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  playSound('click');
                  onSendToSandbox(editorCode);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 transition-all font-medium text-xs"
              >
                <Play className="w-3.5 h-3.5" />
                <span>فحص في المختبر</span>
              </button>

              <button
                onClick={handleDownloadActiveFile}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/5 transition-all text-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تحميل .luau</span>
              </button>

              <button
                onClick={handleCopyEditorCode}
                className={`flex items-center gap-1.5 px-3 py-1 rounded font-medium text-xs transition-all ${
                  copiedCode
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30'
                }`}
              >
                {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'تم النسخ!' : 'نسخ الكود'}</span>
              </button>
            </div>
          </div>

          {/* PC Code Editor with Line Numbers */}
          <div className="flex-1 flex overflow-hidden font-mono text-xs sm:text-[13px] leading-relaxed bg-[#06080e]" dir="ltr">
            
            {/* Line Numbers Gutter */}
            <div className="select-none text-right py-4 pr-3 text-slate-600 border-r border-white/5 bg-[#080b12] min-w-[3rem]">
              {lines.map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>

            {/* Editable Code Area */}
            <textarea
              value={editorCode}
              onChange={(e) => setEditorCode(e.target.value)}
              spellCheck={false}
              className="flex-1 p-4 bg-transparent text-slate-200 placeholder-slate-600 focus:outline-none resize-none overflow-y-auto leading-relaxed selection:bg-cyan-500/30"
            />
          </div>
        </div>
      </div>

      {/* Bottom PC Status Bar */}
      <div className="h-6 border-t border-white/5 bg-[#090d18] px-4 flex items-center justify-between text-[11px] text-slate-400 font-mono select-none">
        <div className="flex items-center gap-4">
          <span className="text-cyan-400 font-bold">Roblox Luau v0.600+</span>
          <span>•</span>
          <span>الأعمدة: {lines.length} سطر</span>
          <span>•</span>
          <span>الترميز: UTF-8</span>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-slate-500 hidden sm:inline">
            اختصارات: <kbd className="text-slate-300">Ctrl+Enter</kbd> إرسال | <kbd className="text-slate-300">Ctrl+C</kbd> نسخ
          </span>
          <span className="text-emerald-400 font-bold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>متصل</span>
          </span>
        </div>
      </div>
    </div>
  );
}
