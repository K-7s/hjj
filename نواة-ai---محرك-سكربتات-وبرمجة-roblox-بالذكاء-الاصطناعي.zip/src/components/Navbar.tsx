import React from 'react';
import { 
  Bot, 
  Wrench, 
  BookOpen, 
  Code2, 
  Activity, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Cpu, 
  ShieldCheck,
  Zap
} from 'lucide-react';
import type { TabId } from '../lib/types';
import { playSound, toggleSound, isSoundEnabled } from '../lib/utils';

interface NavbarProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  serverOnline?: boolean;
}

export function Navbar({ activeTab, onTabChange, serverOnline = true }: NavbarProps) {
  const [soundOn, setSoundOn] = React.useState(isSoundEnabled());

  const handleSoundToggle = () => {
    const next = toggleSound();
    setSoundOn(next);
    if (next) playSound('click');
  };

  const navItems: { id: TabId; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }[] = [
    { id: 'workspace', label: 'مساحة العمل الذكية', icon: Bot, badge: 'AI' },
    { id: 'generator', label: 'مولّد السكربتات', icon: Wrench },
    { id: 'library', label: 'مكتبة الأكواد', icon: BookOpen },
    { id: 'sandbox', label: 'مختبر فحص Luau', icon: Code2 },
    { id: 'pressure', label: 'مقياس التحمل والضغط', icon: Activity, badge: 'Turbo' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-cyan-500/20 bg-[#07090e]/85 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500/30 to-purple-600/30 border border-cyan-400/40 shadow-[0_0_20px_-5px_rgba(34,211,238,0.4)]">
            <Cpu className="w-5 h-5 text-cyan-300" />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-cyan-300 via-sky-200 to-purple-300 bg-clip-text text-transparent">
                نواة AI
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300">
                PRO 3.8 FLASH
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              محرك Luau وRoblox الخارق بأقوى نموذج ذكاء مجاني يتحمل الضغط
            </p>
          </div>
        </div>

        {/* Center Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/70 border border-white/5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  playSound('click');
                  onTabChange(item.id);
                }}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 relative ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/20 to-sky-500/20 text-cyan-300 border border-cyan-500/30 shadow-[0_0_15px_-4px_rgba(34,211,238,0.4)]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-full ${isActive ? 'bg-cyan-500/30 text-cyan-200' : 'bg-slate-800 text-slate-400'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Action Badges */}
        <div className="flex items-center gap-2.5">
          {/* Desktop PC Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-950/40 border border-purple-500/30 text-purple-300 text-xs font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
            <span>🖥️ مخصص للـ PC (استوديو كامل)</span>
          </div>

          {/* AI Model Badge */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-lg bg-cyan-950/50 border border-cyan-500/20 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-300 font-medium">Gemini 3.8 Flash</span>
            <span className="text-[10px] text-cyan-400 font-bold bg-cyan-500/10 px-1.5 py-0.5 rounded">
              صامد للضغط
            </span>
          </div>

          {/* Sound Effect Toggle */}
          <button
            onClick={handleSoundToggle}
            title={soundOn ? 'كتم المؤثرات الصوتية' : 'تفعيل المؤثرات الصوتية'}
            className="p-2 rounded-lg bg-slate-900 border border-white/5 text-slate-400 hover:text-cyan-300 hover:border-cyan-500/30 transition-all"
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-white/5 bg-[#0a0d16] px-2 py-1.5 overflow-x-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                playSound('click');
                onTabChange(item.id);
              }}
              className={`flex flex-col items-center py-1 px-2.5 rounded-lg text-[11px] font-medium transition-all ${
                isActive ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-400'
              }`}
            >
              <Icon className="w-4 h-4 mb-0.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
}
