import type { GeneratedFile, ScriptTemplate } from './types';

const num = (v: unknown, fallback: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

const str = (v: unknown, fallback: string) => {
  const s = String(v ?? '').trim();
  return s.length > 0 ? s : fallback;
};

export const SCRIPT_TEMPLATES: ScriptTemplate[] = [
  {
    id: 'datastore-system',
    name: 'نظام حفظ بيانات متقدم (DataStore System)',
    category: 'backend',
    description: 'نظام آمن لحفظ واسترجاع عملات اللاعب، مستواه، وعناصره مع معالجة pcall التلقائية وحماية من فقدان البيانات.',
    fields: [
      { id: 'storeName', label: 'اسم مخزن البيانات (DataStore Name)', type: 'text', default: 'PlayerData_v1', hint: 'يفضل تغيير الإصدار عند تعديل هيكل البيانات' },
      { id: 'initialCoins', label: 'الكوينز الابتدائية للجدد', type: 'number', default: 100, min: 0 },
      { id: 'initialGems', label: 'الجواهر الابتدائية للجدد', type: 'number', default: 10, min: 0 },
      { id: 'autoSaveInterval', label: 'فترة الحفظ التلقائي (بالثواني)', type: 'number', default: 120, min: 30 },
    ],
    setup: [
      'ضع السكربت داخل ServerScriptService في مكان آمن.',
      'تأكد من تفعيل "Enable Studio Access to API Services" من Game Settings > Security في Roblox Studio.',
    ],
    build: (v) => {
      const storeName = str(v.storeName, 'PlayerData_v1');
      const coins = num(v.initialCoins, 100);
      const gems = num(v.initialGems, 10);
      const interval = num(v.autoSaveInterval, 120);

      return [
        {
          name: 'DataStoreManager',
          location: 'ServerScriptService',
          scriptType: 'Script',
          code: `--[[
	نظام حفظ بيانات اللاعبين المتكامل
	تم التوليد عبر: نواة AI
	المكان: ServerScriptService
]]

local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local PlayerDataStore = DataStoreService:GetDataStore("${storeName}")
local AUTOSAVE_INTERVAL = ${interval}

local sessionData = {}

local function createLeaderstats(player: Player, data: { Coins: number, Gems: number })
	local leaderstats = Instance.new("Folder")
	leaderstats.Name = "leaderstats"
	leaderstats.Parent = player

	local coinsVal = Instance.new("IntValue")
	coinsVal.Name = "Coins"
	coinsVal.Value = data.Coins
	coinsVal.Parent = leaderstats

	local gemsVal = Instance.new("IntValue")
	gemsVal.Name = "Gems"
	gemsVal.Value = data.Gems
	gemsVal.Parent = leaderstats
end

local function loadData(player: Player)
	local userId = player.UserId
	local key = "Player_" .. userId
	local success, data = pcall(function()
		return PlayerDataStore:GetAsync(key)
	end)

	if success and data then
		sessionData[player] = data
	else
		sessionData[player] = {
			Coins = ${coins},
			Gems = ${gems},
			Inventory = {},
		}
	end

	createLeaderstats(player, sessionData[player])
end

local function saveData(player: Player)
	if not sessionData[player] then return end
	local key = "Player_" .. player.UserId
	local leaderstats = player:FindFirstChild("leaderstats")
	if leaderstats then
		local coinsVal = leaderstats:FindFirstChild("Coins") :: IntValue?
		local gemsVal = leaderstats:FindFirstChild("Gems") :: IntValue?
		if coinsVal then sessionData[player].Coins = coinsVal.Value end
		if gemsVal then sessionData[player].Gems = gemsVal.Value end
	end

	local success, err = pcall(function()
		PlayerDataStore:SetAsync(key, sessionData[player])
	end)

	if not success then
		warn(string.format("فشل حفظ بيانات %s: %s", player.Name, tostring(err)))
	end
end

Players.PlayerAdded:Connect(loadData)
Players.PlayerRemoving:Connect(function(player)
	saveData(player)
	sessionData[player] = nil
end)

-- دورة الحفظ التلقائي الدوري
task.spawn(function()
	while true do
		task.wait(AUTOSAVE_INTERVAL)
		for _, player in ipairs(Players:GetPlayers()) do
			saveData(player)
		end
	end
end)

-- حفظ كل اللاعبين عند إغلاق السيرفر
game:BindToClose(function()
	if RunService:IsStudio() then task.wait(1) end
	for _, player in ipairs(Players:GetPlayers()) do
		saveData(player)
	end
end)`,
        },
      ];
    },
  },
  {
    id: 'combat-raycast',
    name: 'نظام سلاح ورمي بالأشعة (Raycast Gun System)',
    category: 'gameplay',
    description: 'نظام إطلاق نار فيزيائي ثلاثي الأبعاد مع التحقق من الإصابة على الخادم، مؤثرات الرصاص، ومسافات دقيقة.',
    fields: [
      { id: 'damage', label: 'مقدار الضرر للطلقة (Damage)', type: 'number', default: 35, min: 1 },
      { id: 'fireRate', label: 'معدل الإطلاق (فترة التهدئة بالثواني)', type: 'number', default: 0.15, min: 0.05, step: 0.01 },
      { id: 'maxDistance', label: 'المدى الأقصى للطلقة (Studs)', type: 'number', default: 300, min: 50 },
      { id: 'headshotMultiplier', label: 'مضاعف ضرر الرأس (Headshot)', type: 'number', default: 2, min: 1 },
    ],
    setup: [
      'أنشئ RemoteEvent باسم "ShootEvent" داخل ReplicatedStorage.',
      'ضع سكربت العميل (Client) كـ LocalScript داخل الأداة Tool.',
      'ضع سكربت الخادم (Server) داخل ServerScriptService.',
    ],
    build: (v) => {
      const dmg = num(v.damage, 35);
      const rate = num(v.fireRate, 0.15);
      const dist = num(v.maxDistance, 300);
      const headMult = num(v.headshotMultiplier, 2);

      return [
        {
          name: 'GunServerHandler',
          location: 'ServerScriptService',
          scriptType: 'Script',
          code: `--[[
	خادم التحقق من إطلاق النار وتطبيق الضرر
	المكان: ServerScriptService
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local remote = ReplicatedStorage:WaitForChild("ShootEvent") :: RemoteEvent

local BASE_DAMAGE = ${dmg}
local HEAD_MULTIPLIER = ${headMult}
local MAX_RANGE = ${dist}
local FIRE_RATE = ${rate}

local lastShotTime = {}

remote.OnServerEvent:Connect(function(player, origin: Vector3, direction: Vector3)
	-- تحقق زمني من وتيرة الإطلاق لمنع استغلال الهاكات
	local now = os.clock()
	if lastShotTime[player] and now - lastShotTime[player] < (FIRE_RATE * 0.8) then
		return
	end
	lastShotTime[player] = now

	local character = player.Character
	if not character or not character:FindFirstChild("HumanoidRootPart") then return end

	-- تحقق أن نقطة البداية قريبة من شخصية اللاعب
	local rootPos = character.HumanoidRootPart.Position
	if (origin - rootPos).Magnitude > 20 then
		return
	end

	-- تنفيذ الفحص بالأشعة على الخادم حصراً
	local rayParams = RaycastParams.new()
	rayParams.FilterDescendantsInstances = { character }
	rayParams.FilterType = RaycastFilterType.Exclude

	local rayResult = workspace:Raycast(origin, direction.Unit * MAX_RANGE, rayParams)

	if rayResult and rayResult.Instance then
		local hitChar = rayResult.Instance:FindFirstAncestorOfClass("Model")
		if hitChar and hitChar ~= character then
			local humanoid = hitChar:FindFirstChildOfClass("Humanoid")
			if humanoid and humanoid.Health > 0 then
				local isHeadshot = rayResult.Instance.Name == "Head"
				local finalDamage = isHeadshot and (BASE_DAMAGE * HEAD_MULTIPLIER) or BASE_DAMAGE
				humanoid:TakeDamage(finalDamage)
			end
		end
	end
end)`,
        },
        {
          name: 'GunClientController',
          location: 'Tool/Gun (LocalScript)',
          scriptType: 'LocalScript',
          code: `--[[
	تحكم السلاح من طرف العميل
	المكان: كـ LocalScript داخل الأداة Tool
]]

local Tool = script.Parent
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local remote = ReplicatedStorage:WaitForChild("ShootEvent") :: RemoteEvent
local player = Players.LocalPlayer
local mouse = player:GetMouse()

local canShoot = true
local FIRE_RATE = ${rate}

Tool.Activated:Connect(function()
	if not canShoot then return end
	canShoot = false

	local character = player.Character
	if not character or not character:FindFirstChild("HumanoidRootPart") then return end

	local handle = Tool:FindFirstChild("Handle") or character.HumanoidRootPart
	local origin = handle.Position
	local targetPos = mouse.Hit.Position
	local direction = (targetPos - origin).Unit

	remote:FireServer(origin, direction)

	task.wait(FIRE_RATE)
	canShoot = true
end)`,
        },
      ];
    },
  },
  {
    id: 'sprint-stamina',
    name: 'نظام الجري مع طاقة متجددة (Sprint & Stamina)',
    category: 'gameplay',
    description: 'نظام جري متقدم مع مفتاح Shift، شريط طاقة ينقص عند الركض ويتجدد تدريجياً، مع قيود أمان تمنع المشي السريع بلا نهاية.',
    fields: [
      { id: 'normalSpeed', label: 'السرعة العادية (WalkSpeed)', type: 'number', default: 16, min: 10 },
      { id: 'sprintSpeed', label: 'سرعة الركض (SprintSpeed)', type: 'number', default: 28, min: 20 },
      { id: 'maxStamina', label: 'الطاقة القصوى (Max Stamina)', type: 'number', default: 100, min: 50 },
      { id: 'drainRate', label: 'معدل استهلاك الطاقة بالثانية', type: 'number', default: 20, min: 5 },
      { id: 'regenRate', label: 'معدل تجدد الطاقة بالثانية', type: 'number', default: 15, min: 5 },
    ],
    setup: [
      'ضع السكربت داخل StarterPlayer/StarterPlayerScripts كـ LocalScript.',
    ],
    build: (v) => {
      const normalSpeed = num(v.normalSpeed, 16);
      const sprintSpeed = num(v.sprintSpeed, 28);
      const maxStamina = num(v.maxStamina, 100);
      const drain = num(v.drainRate, 20);
      const regen = num(v.regenRate, 15);

      return [
        {
          name: 'StaminaSprintController',
          location: 'StarterPlayerScripts',
          scriptType: 'LocalScript',
          code: `--[[
	نظام الجري واستهلاك الطاقة المتجددة
	المكان: StarterPlayer/StarterPlayerScripts (LocalScript)
]]

local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")

local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid") :: Humanoid

local NORMAL_SPEED = ${normalSpeed}
local SPRINT_SPEED = ${sprintSpeed}
local MAX_STAMINA = ${maxStamina}
local DRAIN_RATE = ${drain}
local REGEN_RATE = ${regen}

local currentStamina = MAX_STAMINA
local isSprinting = false

UserInputService.InputBegan:Connect(function(input, gp)
	if gp then return end
	if input.KeyCode == Enum.KeyCode.LeftShift then
		isSprinting = true
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.KeyCode == Enum.KeyCode.LeftShift then
		isSprinting = false
	end
end)

RunService.RenderStepped:Connect(function(dt)
	local isMoving = humanoid.MoveDirection.Magnitude > 0.1

	if isSprinting and isMoving and currentStamina > 0 then
		currentStamina = math.max(0, currentStamina - (DRAIN_RATE * dt))
		humanoid.WalkSpeed = SPRINT_SPEED
	else
		currentStamina = math.min(MAX_STAMINA, currentStamina + (REGEN_RATE * dt))
		humanoid.WalkSpeed = NORMAL_SPEED
		if currentStamina <= 0 then
			isSprinting = false
		end
	end
end)`,
        },
      ];
    },
  },
  {
    id: 'daily-reward',
    name: 'مكافأة تسجيل الدخول اليومي (Daily Reward Streak)',
    category: 'economy',
    description: 'نظام حوافز يومي يمنح اللاعب عملات عند الدخول كل 24 ساعة، مع حساب السلسلة المتواصلة (Streak) ومضاعفة الجوائز.',
    fields: [
      { id: 'baseReward', label: 'المكافأة الأساسية (اليوم الأول)', type: 'number', default: 250, min: 50 },
      { id: 'streakBonus', label: 'مضاعف كل يوم متواصل (Streak Bonus)', type: 'number', default: 50, min: 10 },
      { id: 'maxDays', label: 'أقصى أيام السلسلة (Max Streak)', type: 'number', default: 7, min: 5 },
    ],
    setup: [
      'ضع السكربت داخل ServerScriptService.',
      'أنشئ RemoteEvent باسم "DailyRewardNotification" داخل ReplicatedStorage لإظهار التنبيه.',
    ],
    build: (v) => {
      const base = num(v.baseReward, 250);
      const bonus = num(v.streakBonus, 50);
      const maxStreak = num(v.maxDays, 7);

      return [
        {
          name: 'DailyRewardManager',
          location: 'ServerScriptService',
          scriptType: 'Script',
          code: `--[[
	نظام المكافآت اليومية المتتابعة (Daily Login Streak)
	المكان: ServerScriptService
]]

local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")

local RewardStore = DataStoreService:GetDataStore("DailyLoginRewards_v1")
local DAY_SECONDS = 86400
local STREAK_RESET_WINDOW = 86400 * 2 -- إعادة التصفير إذا غاب أكثر من 48 ساعة

local BASE_REWARD = ${base}
local BONUS_PER_DAY = ${bonus}
local MAX_STREAK = ${maxStreak}

local function checkDailyReward(player: Player)
	local key = "DailyReward_" .. player.UserId
	local success, data = pcall(function()
		return RewardStore:GetAsync(key)
	end)

	local now = os.time()
	local lastClaim = (success and data and data.LastClaim) or 0
	local streak = (success and data and data.Streak) or 0

	local elapsed = now - lastClaim

	if elapsed >= DAY_SECONDS then
		-- تحقق إذا كانت السلسلة مستمرة أم انقطعت
		if elapsed > STREAK_RESET_WINDOW then
			streak = 1
		else
			streak = math.min(MAX_STREAK, streak + 1)
		end

		local rewardAmount = BASE_REWARD + ((streak - 1) * BONUS_PER_DAY)

		-- إضافة المكافأة إلى الـ leaderstats
		local leaderstats = player:WaitForChild("leaderstats", 5)
		if leaderstats and leaderstats:FindFirstChild("Coins") then
			leaderstats.Coins.Value += rewardAmount
		end

		-- حفظ التاريخ الجديد
		pcall(function()
			RewardStore:SetAsync(key, {
				LastClaim = now,
				Streak = streak,
			})
		end)

		print(string.format("حصل %s على المكافأة اليومية: %d كوينز! (اليوم %d)", player.Name, rewardAmount, streak))
	end
end

Players.PlayerAdded:Connect(checkDailyReward)`,
        },
      ];
    },
  },
];
