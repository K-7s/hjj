import type { Block, EngineResult } from '../types';

type LuauIntent = {
  id: string;
  title: string;
  match: RegExp;
  location: string;
  scriptType: 'Script' | 'LocalScript' | 'ModuleScript';
  explain: string;
  code: (n: number | null) => string;
};

const INTENTS: LuauIntent[] = [
  {
    id: 'killbrick',
    title: 'جزء قاتل فوري (Kill Brick / Lava)',
    match: /قاتل|يقتل|kill|lava|حمم|لافا|die|موت/i,
    location: 'داخل الـ Part نفسه (Server Script)',
    scriptType: 'Script',
    explain: 'عند لمس اللاعب للجزء يتم تصفير صحته فوراً مع حماية من تكرار الأحداث وتأكيد وجود الشخصية.',
    code: () => `local part = script.Parent

part.Touched:Connect(function(hit)
	local character = hit.Parent
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	if humanoid and humanoid.Health > 0 then
		humanoid.Health = 0
	end
end)`,
  },
  {
    id: 'teleport',
    title: 'نظام انتقال فوري (Teleport Pad)',
    match: /انتقال|نقل|تنقل|teleport|tp\b|بوابة|portal/i,
    location: 'داخل الـ Part الأول (المنصة) مع جزء Destination في Workspace',
    scriptType: 'Script',
    explain: 'ينقل اللاعب إلى جزء الوجهة (Destination) مع فترة تهدئة (Cooldown) لمنع التكرار اللانهائي.',
    code: (n) => `local pad = script.Parent
local destination = workspace:WaitForChild("Destination")
local COOLDOWN = ${n ?? 3}
local recentlyTeleported = {}

pad.Touched:Connect(function(hit)
	local character = hit.Parent
	local humanoid = character:FindFirstChildOfClass("Humanoid")
	local rootPart = character:FindFirstChild("HumanoidRootPart")
	
	if not humanoid or not rootPart or recentlyTeleported[character] then
		return
	end
	
	recentlyTeleported[character] = true
	character:PivotTo(destination.CFrame + Vector3.new(0, 3, 0))
	
	task.delay(COOLDOWN, function()
		recentlyTeleported[character] = nil
	end)
end)`,
  },
  {
    id: 'leaderstats',
    title: 'نظام النقاط والقوائم (Leaderstats & Coins)',
    match: /ليدر|leaderstats|نقاط|عملات|فلوس|coins|gold|points|money/i,
    location: 'داخل ServerScriptService كـ Script عادي',
    scriptType: 'Script',
    explain: 'ينشئ مجلد leaderstats الرسمي عند دخول أي لاعب لإظهار الكوينز والمستوى في القائمة العلوية.',
    code: () => `local Players = game:GetService("Players")

local function onPlayerAdded(player: Player)
	local leaderstats = Instance.new("Folder")
	leaderstats.Name = "leaderstats"
	leaderstats.Parent = player

	local coins = Instance.new("IntValue")
	coins.Name = "Coins"
	coins.Value = 100
	coins.Parent = leaderstats

	local level = Instance.new("IntValue")
	level.Name = "Level"
	level.Value = 1
	level.Parent = leaderstats
end

Players.PlayerAdded:Connect(onPlayerAdded)`,
  },
  {
    id: 'sprint',
    title: 'نظام الجري مع Shift (Sprint System)',
    match: /ركض|سبرنت|جري|sprint|shift|سرعة/i,
    location: 'داخل StarterPlayer/StarterPlayerScripts كـ LocalScript',
    scriptType: 'LocalScript',
    explain: 'يتحكم في سرعة اللاعب محلياً عند الضغط على مفتاح Shift الأيسر مع إعادة السرعة للطبيعية عند الإفلات.',
    code: (n) => `local UserInputService = game:GetService("UserInputService")
local Players = game:GetService("Players")

local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid") :: Humanoid

local NORMAL_SPEED = 16
local SPRINT_SPEED = ${n ?? 28}

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then return end
	if input.KeyCode == Enum.KeyCode.LeftShift then
		humanoid.WalkSpeed = SPRINT_SPEED
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.KeyCode == Enum.KeyCode.LeftShift then
		humanoid.WalkSpeed = NORMAL_SPEED
	end
end)`,
  },
  {
    id: 'doublejump',
    title: 'قفز مزدوج (Double Jump System)',
    match: /قفز|jump|دبل|مزدوج|double\s*jump/i,
    location: 'داخل StarterPlayer/StarterPlayerScripts كـ LocalScript',
    scriptType: 'LocalScript',
    explain: 'يمنح اللاعب إمكانية القفز في الهواء لمرة إضافية مع تأثير حركي فوري وإعادة التعيين عند لمس الأرض.',
    code: () => `local UserInputService = game:GetService("UserInputService")
local Players = game:GetService("Players")

local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid") :: Humanoid
local rootPart = character:WaitForChild("HumanoidRootPart") :: BasePart

local canDoubleJump = false
local hasDoubleJumped = false
local JUMP_POWER = 50

humanoid.StateChanged:Connect(function(_, newState)
	if newState == Enum.HumanoidStateType.Landed then
		canDoubleJump = false
		hasDoubleJumped = false
	elseif newState == Enum.HumanoidStateType.Freefall then
		task.wait(0.1)
		canDoubleJump = true
	end
end)

UserInputService.JumpRequest:Connect(function()
	if canDoubleJump and not hasDoubleJumped then
		hasDoubleJumped = true
		canDoubleJump = false
		rootPart.AssemblyLinearVelocity = Vector3.new(rootPart.AssemblyLinearVelocity.X, JUMP_POWER, rootPart.AssemblyLinearVelocity.Z)
	end
end)`,
  },
  {
    id: 'anticheat',
    title: 'نظام حماية من تسريع المشي (Server Anti-Speed Exploit)',
    match: /حماية|هاك|سبيد|anti|exploit|cheat|غش/i,
    location: 'داخل ServerScriptService كـ Script',
    scriptType: 'Script',
    explain: 'يراقب إزاحة اللاعب الحقيقية على الخادم ويكشف الهاكات وتجاوز السرعة القصوى مع إعادة اللاعب لمكانه.',
    code: () => `local Players = game:GetService("Players")

local MAX_ALLOWED_SPEED = 24
local CHECK_INTERVAL = 0.5

Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(function(character)
		local rootPart = character:WaitForChild("HumanoidRootPart") :: BasePart
		local lastPosition = rootPart.Position
		local lastCheck = os.clock()

		while character.Parent do
			task.wait(CHECK_INTERVAL)
			local now = os.clock()
			local dt = now - lastCheck
			local distance = (rootPart.Position - lastPosition).Magnitude
			local speed = distance / dt

			if speed > (MAX_ALLOWED_SPEED * 1.5) then
				warn(string.format("تحذير أمان: %s تجاوز حد السرعة المسموح! (السرعة: %.1f)", player.Name, speed))
				rootPart.CFrame = CFrame.new(lastPosition)
			else
				lastPosition = rootPart.Position
			end
			lastCheck = now
		end
	end)
end)`,
  },
];

export function runLuauHelper(prompt: string): EngineResult {
  const matched = INTENTS.find((i) => i.match.test(prompt));

  if (matched) {
    return {
      blocks: [
        { kind: 'heading', content: `⚡ تم التوليد بنجاح: ${matched.title}` },
        { kind: 'text', content: matched.explain },
        {
          kind: 'note',
          tone: 'info',
          content: `المكان المطلوب: ${matched.location} (${matched.scriptType})`,
        },
        {
          kind: 'code',
          lang: 'luau',
          content: matched.code(null),
          title: `${matched.id}.luau`,
          location: matched.location,
        },
        {
          kind: 'list',
          ordered: false,
          items: [
            'الكود متوافق 100% مع أحدث معايير Roblox Luau الصارمة.',
            'تم استخدام task library بدلاً من دوال wait القديمة.',
            'جاهز للنسخ بنقرة واحدة ونقله مباشرة إلى Roblox Studio.',
          ],
        },
      ],
    };
  }

  // Generic fallback if not matched
  return {
    blocks: [
      { kind: 'heading', content: 'نظام Luau مخصص للمطور' },
      { kind: 'text', content: `إليك الهيكل البرمجي المقترح لطلبك: "${prompt}" وفق أفضل ممارسات Roblox الحديثة:` },
      {
        kind: 'code',
        lang: 'luau',
        title: 'SystemModule.luau',
        location: 'ReplicatedStorage/Modules',
        content: `--[[
	نظام تم إنشاؤه عبر نواة AI
	الطلب: ${prompt}
]]

local System = {}
System.__index = System

function System.new()
	local self = setmetatable({}, System)
	self.Enabled = true
	return self
end

function System:Init()
	print("تم تهيئة النظام بنجاح!")
end

function System:Process(player: Player, data: any)
	if not self.Enabled then return end
	assert(typeof(player) == "Instance" and player:IsA("Player"), "لاعب غير صالح")
	
	-- تنفيذ العمليات البرمجية الآمنة
	return true
end

return System`,
      },
      {
        kind: 'note',
        tone: 'info',
        content: 'نصيحة: يمكنك تفعيل وضع Gemini 3.8 Flash للحصول على أكواد متقدمة ودقيقة للغاية لأي فكرة في مخيلتك!',
      },
    ],
  };
}
