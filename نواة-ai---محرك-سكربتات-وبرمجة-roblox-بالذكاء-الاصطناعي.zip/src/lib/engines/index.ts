import type { Engine, EngineId } from '../types';
import { runLuauHelper } from './luau-helper';

export const ENGINES: Engine[] = [
  {
    id: 'architect',
    name: 'مهندس أنظمة ألعاب Roblox',
    tagline: 'أنظمة متكاملة، شبكات، DataStores، وبرمجة OOP بمعايير استوديوهات Roblox العالمية',
    badge: 'الأكثر ذكاءً',
    iconName: 'Cpu',
    placeholder: 'مثال: ابنِ لي نظام متجر أسلحة كامل يربط بين الخادم والعميل مع حفظ البيانات في DataStore...',
    suggestions: [
      'نظام حفظ بيانات اللاعبين عبر ProfileService مع حماية من خسارة البيانات',
      'نظام متجر وترقية أسلحة مع فحص الرصيد على الخادم ومؤثرات صوتية',
      'نظام جولات (Round System) لـ 10 لاعبين مع عد تنازلي وتحديد الفائز',
      'نظام حيوانات أليفة (Pet System) تتبع اللاعب بسلاسة باستخدام AlignPosition',
    ],
    options: [
      {
        id: 'paradigm',
        label: 'أسلوب البرمجة',
        choices: [
          { value: 'oop', label: 'كائني التوجه (OOP / Metatables)' },
          { value: 'modular', label: 'وحدات معيارية (ModuleScripts)' },
          { value: 'service', label: 'خدمات موحدة (Service Architecture)' },
        ],
      },
      {
        id: 'storage',
        label: 'طريقة الحفظ',
        choices: [
          { value: 'profileservice', label: 'ProfileService (موصى به)' },
          { value: 'datastore2', label: 'DataStore2' },
          { value: 'vanilla', label: 'DataStoreService الافتراضي' },
        ],
      },
    ],
    systemPrompt: `أنت مهندس أنظمة ألعاب Roblox رفيع المستوى (Roblox Senior Architect).
مهمتك: تصميم وكتابة أنظمة ألعاب قوية ومعيارية باستخدام Luau الحديث.
- دائماً قسّم الكود إلى أجزاء واضحة (ServerScriptService, ReplicatedStorage, StarterPlayerScripts).
- استخدم معايير Luau الصارمة (Type Checking، task library).
- اشرح كيفية تركيب وتشغيل السكربتات خطوة بخطوة في Roblox Studio.`,
  },
  {
    id: 'security',
    name: 'خبير الحماية ومكافحة الهاكات',
    tagline: 'تدقيق أمني، سد ثغرات الـ RemoteEvents، ومنع الغش والتلاعب (Anti-Exploit)',
    badge: 'حماية قصوى',
    iconName: 'ShieldAlert',
    placeholder: 'ضع سكربت الخادم أو اشرح النظام المراد حمايته من الهاكات وحقن الأكواد...',
    suggestions: [
      'فحص وتأمين RemoteEvent لشراء الأدوات من التكرار المزور وحقن المعاملات',
      'نظام Server-Side لمنع الطيران وتخطي الجدران (Anti-Fly & Anti-NoClip)',
      'حماية ليدرستات النقاط من تلاعب السكربتات التنفيذية وحقن القيم السالبة',
      'نظام Rate Limiting ذكي لمنع حجب الخدمة (DDoS / Remote Spamming)',
    ],
    options: [
      {
        id: 'strictness',
        label: 'مستوى التدقيق',
        choices: [
          { value: 'hardcore', label: 'حماية مشددة (طرد فوري للمخالف)' },
          { value: 'safe', label: 'إعادة ضبط سلسة (Rubberbanding / Logging)' },
          { value: 'stealth', label: 'سجل صامت للتأكد (Silent Logging)' },
        ],
      },
    ],
    systemPrompt: `أنت خبير أمن ألعاب واختراق أخلاقي متخصص في منصة Roblox ومكافحة السكربتات التنفيذية (Exploit Defense).
قواعدك:
- لا تثق أبداً في مدخلات العميل (Never trust the client).
- تحقّق من نوع ومقدار وأصل كل معامل في OnServerEvent.
- ضع فحوصات مسافة (Sanity Checks)، فحوصات توقيت (Debounce/Rate Limit)، ومقارنة الحالة مع الخادم.`,
  },
  {
    id: 'debugger',
    name: 'مصلح الأخطاء ومصحح السكربتات',
    tagline: 'تحليل مخرجات الخطأ (Output Errors)، كشف تسرب الذاكرة، وتقديم الكود المصحح',
    badge: 'حل فوري',
    iconName: 'Wrench',
    placeholder: 'الصق رسالة الخطأ من الـ Output أو الكود الذي لا يعمل كما تتوقع...',
    suggestions: [
      'حل خطأ: Infinite yield possible on ReplicatedStorage:WaitForChild("Events")',
      'حل خطأ: attempt to index nil with "Health" في دالة Touched',
      'حل مشكلة السكربت الذي يعمل على الخادم لكن لا يستجيب في شاشة اللاعب',
      'تحسين استهلاك الذاكرة وتفادي تسريب الأحداث التراكمية (Memory Leaks)',
    ],
    options: [
      {
        id: 'depth',
        label: 'تفصيل التحليل',
        choices: [
          { value: 'thorough', label: 'تحليل عميق + كود كامل مصحح' },
          { value: 'quick', label: 'إصلاح سريع ومباشر' },
        ],
      },
    ],
    systemPrompt: `أنت خبير تنقيح أخطاء Luau وRoblox Engine (Bug Fixer & Profiler).
عند تقديم كود أو رسالة خطأ:
1. اشرح فوراً وبدقة سبب حدوث الخطأ (Root Cause).
2. اعرض الكود المصحح بالكامل داخل قالب كود بلسان luau.
3. وضّح الفرق بين الكود القديم والجديد وكيف تتجنب تكرار المشكلة مستقبلاً.`,
  },
  {
    id: 'ui',
    name: 'مصمم واجهات وأنظمة UI الحركية',
    tagline: 'أنظمة TweenService، واجهات متجاوبة، أشرطة طاقة، وقوائم سينمائية تفاعلية',
    badge: 'تصميم سينمائي',
    iconName: 'Palette',
    placeholder: 'صف الواجهة المطلوبة (مثال: شريط صحة متدرج يتحرك بسلاسة عند الضرر مع صوت خافت)...',
    suggestions: [
      'شريط صحة وطاقة (Health & Stamina Bar) بتدرج نيون وتحريك سلس مع TweenService',
      'قائمة متجر سفلية (Modern Bottom Bar) قابلة للفتح والإغلاق بلمسات ناعمة',
      'واجهة فتح صناديق الحظ (Lootbox Rolling System) بنمط كازينو متحرك',
      'نظام إشعارات عائمة (Floating Toast Notifications) تظهر وتختفي تلقائياً',
    ],
    options: [
      {
        id: 'easing',
        label: 'نمط الحركة (Easing)',
        choices: [
          { value: 'quad', label: 'Quad (حركة ناعمة طبيعية)' },
          { value: 'elastic', label: 'Elastic (ارتداد مرن حيوي)' },
          { value: 'bounce', label: 'Bounce (قفز ارتدادي)' },
        ],
      },
    ],
    systemPrompt: `أنت فنان ومبرمج واجهات مستخدم متقدم في Roblox (UI/UX Motion Developer).
- استخدم TweenService مع EasingDirection و EasingStyle المناسب للحركة.
- استخدم UDim2.fromScale لجعل الواجهات متوافقة مع شاشات الجوال والكمبيوتر والكونسول.
- أضف مؤثرات بصرية وصوتية لتعزيز الشعور بالاحترافية.`,
  },
  {
    id: 'prompt',
    name: 'مهندس البرومبتات الذكية',
    tagline: 'توليد برومبتات فائقة الدقة والفعالية لـ Roblox Studio AI، Claude، وGemini',
    badge: 'هندسة أوامر',
    iconName: 'Sparkles',
    placeholder: 'أدخل فكرتك باللغة العامية وسأحولها إلى برومبت متكامل جاهز للمحركات الكبرى...',
    suggestions: [
      'برومبت لتوليد لعبة Tycoon كاملة بأزرار الشراء والمصاعد الآلية',
      'برومبت لبناء نظام قتال سيوف ثلاثي الأبعاد مع ضربات متتالية (Combos)',
      'برومبت لتوليد نصوص قصة وحوارات شخصيات NPC تفاعلية داخل اللعبة',
      'برومبت لتحسين أداء اللعبة وتقليل اللاغ للخرائط الضخمة',
    ],
    options: [
      {
        id: 'targetModel',
        label: 'النموذج المستهدف',
        choices: [
          { value: 'gemini', label: 'Google Gemini 3.8 Flash' },
          { value: 'studio', label: 'Roblox Studio Assistant' },
          { value: 'claude', label: 'Claude 3.7 / 3.5 Sonnet' },
        ],
      },
    ],
    systemPrompt: `أنت مهندس أوامر ذكاء اصطناعي محترف (Prompt Engineer).
عند استلام فكرة لعبة أو نظام:
- قم بصياغة برومبت هيكلي متقن يحتوي على:
  1. الدور والسياق المحدد (Persona & Role).
  2. قيود البرمجة الصارمة (Constraints & Standards).
  3. هيكل الإخراج المطلوب (Expected Architecture & Files).
  4. تعليمات الأمان والتحقق (Validation Rules).`,
  },
  {
    id: 'luau_classic',
    name: 'المولد المحلي الفوري (Turbo Offline)',
    tagline: 'توليد فوري بسرعة الضوء داخل المتصفح بدون استهلاك بيانات أو انتظار اتصال الخادم',
    badge: 'فوري 0ms',
    iconName: 'Zap',
    placeholder: 'اكتب ما تريده (مثال: جزء قاتل، بوابة انتقال، قفز مزدوج، ليدرستات)...',
    suggestions: [
      'جزء قاتل فوري (Kill Brick)',
      'بوابة انتقال بين نقطتين مع فترة تهدئة',
      'نظام ليدرستات وعملات عند الدخول',
      'نظام ركض سريع مع مفتاح Shift الأيسر',
    ],
    options: [],
    systemPrompt: 'المحرك المحلي الفوري لتوليد سكربتات Luau سريعة ومعيارية.',
    runLocal: (input: string) => runLuauHelper(input),
  },
];

export function getEngine(id: EngineId): Engine {
  return ENGINES.find((e) => e.id === id) ?? ENGINES[0];
}
