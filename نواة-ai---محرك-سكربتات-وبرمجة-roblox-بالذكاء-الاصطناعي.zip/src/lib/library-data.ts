import type { LibraryCategory, LibraryItem } from './types';

export const LIBRARY_CATEGORIES: { id: LibraryCategory; label: string }[] = [
  { id: 'all', label: 'جميع السكربتات' },
  { id: 'gameplay', label: 'أنظمة لعب وحركة (Gameplay)' },
  { id: 'security', label: 'أمان ومكافحة هاكات (Security)' },
  { id: 'systems', label: 'أنظمة خادم وشبكات (Systems)' },
  { id: 'ui', label: 'واجهات ومؤثرات (UI/UX)' },
  { id: 'prompts', label: 'أوامر وبرومبتات AI (Prompts)' },
];

export const LIBRARY_ITEMS: LibraryItem[] = [
  {
    id: 'remote-security-ratelimit',
    title: 'RemoteEvent محمي مع فحص النوع ومعدل الطلبات',
    description: 'نمط احترافي لاستقبال طلبات العميل مع التحقق من نوع المعاملات وتطبيق Rate-Limiter لمنع هجمات السبام.',
    category: 'security',
    lang: 'luau',
    location: 'ServerScriptService',
    tags: ['أمان', 'RemoteEvent', 'Server', 'Anti-Spam'],
    content: `local ReplicatedStorage = game:GetService("ReplicatedStorage")
local remote = Instance.new("RemoteEvent")
remote.Name = "BuyShopItem"
remote.Parent = ReplicatedStorage

local RATE_LIMIT = 0.5 -- نصف ثانية بين كل طلب
local lastCall = {}

remote.OnServerEvent:Connect(function(player: Player, itemId: any, count: any)
	-- 1. التحقق الصارم من نوع المعاملات
	if typeof(itemId) ~= "string" or #itemId > 32 or #itemId == 0 then
		warn("تحذير أمني: محاولة إرسال معرف عنصر غير صالح من: " .. player.Name)
		return
	end

	if typeof(count) ~= "number" or count <= 0 or count > 99 or math.floor(count) ~= count then
		warn("تحذير أمني: كمية غير صالحة مرسلة من: " .. player.Name)
		return
	end

	-- 2. التحقق من معدل الطلبات (Debounce / Rate Limit)
	local now = os.clock()
	if lastCall[player] and now - lastCall[player] < RATE_LIMIT then
		return
	end
	lastCall[player] = now

	-- 3. معالجة الشراء من الخادم حصراً
	local leaderstats = player:FindFirstChild("leaderstats")
	local coins = leaderstats and leaderstats:FindFirstChild("Coins") :: IntValue?
	if coins and coins.Value >= (100 * count) then
		coins.Value -= (100 * count)
		print(string.format("نجح الشراء: اشترى %s عدد %d من %s", player.Name, count, itemId))
	end
end)`,
  },
  {
    id: 'anti-fly-noclip',
    title: 'نظام حماية الخادم من الطيران وتخطي الجدران (Anti-Fly/NoClip)',
    description: 'نظام يراقب حركة اللاعب وحالته الفيزيائية على السيرفر مباشرة لكشف التطفو الممنوع واختراق الأجسام.',
    category: 'security',
    lang: 'luau',
    location: 'ServerScriptService',
    tags: ['Anti-Exploit', 'Physics', 'Server-Side'],
    content: `local Players = game:GetService("Players")

local MAX_FLOAT_TIME = 2.5 -- أقصى مدة بقاء في الهواء بدون أرضية
local CHECK_INTERVAL = 0.5

Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(function(character)
		local humanoid = character:WaitForChild("Humanoid") :: Humanoid
		local rootPart = character:WaitForChild("HumanoidRootPart") :: BasePart
		local floatDuration = 0

		while character.Parent do
			task.wait(CHECK_INTERVAL)
			local state = humanoid:GetState()

			-- فحص إذا كان في حالة السقوط الحر أو القفز لفترة غير طبيعية
			if state == Enum.HumanoidStateType.Freefall or state == Enum.HumanoidStateType.Jumping then
				-- فحص وجود أرضية أسفله بالأشعة
				local ray = workspace:Raycast(rootPart.Position, Vector3.new(0, -10, 0))
				if not ray then
					floatDuration += CHECK_INTERVAL
					if floatDuration > MAX_FLOAT_TIME then
						warn("اشتباه طيران من: " .. player.Name)
						-- إعادة اللاعب إلى آخر موقع آمن أو إسقاطه
						humanoid:ChangeState(Enum.HumanoidStateType.Ragdoll)
						floatDuration = 0
					end
				else
					floatDuration = 0
				end
			else
				floatDuration = 0
			end
		end
	end)
end)`,
  },
  {
    id: 'smooth-pet-following',
    title: 'نظام حيوانات أليفة تتبع اللاعب بفيزياء سلسة (Smooth Pets)',
    description: 'يجعل الموديل يطفو ويتبع كتف اللاعب بسلاسة باستخدام AlignPosition و AlignOrientation بدون تقطيع.',
    category: 'gameplay',
    lang: 'luau',
    location: 'ServerScriptService or ModuleScript',
    tags: ['Pets', 'Physics', 'AlignPosition', 'Tween'],
    content: `local PetSystem = {}

function PetSystem.AttachPet(character: Model, petModel: Model)
	local rootPart = character:WaitForChild("HumanoidRootPart") :: BasePart
	local petRoot = petModel:WaitForChild("RootPart") :: BasePart

	-- جعل أجزاء الحيوان لا تتصادم مع اللاعب
	for _, part in ipairs(petModel:GetDescendants()) do
		if part:IsA("BasePart") then
			part.CanCollide = false
			part.Massless = true
		end
	end

	-- إنشاء مرفقات التثبيت الفيزيائي
	local charAttachment = Instance.new("Attachment")
	charAttachment.Position = Vector3.new(3, 1.5, 3) -- الإزاحة خلف الكتف الأيمن
	charAttachment.Parent = rootPart

	local petAttachment = Instance.new("Attachment")
	petAttachment.Parent = petRoot

	local alignPos = Instance.new("AlignPosition")
	alignPos.Mode = Enum.PositionAlignmentMode.TwoAttachment
	alignPos.Attachment0 = petAttachment
	alignPos.Attachment1 = charAttachment
	alignPos.MaxForce = 15000
	alignPos.Responsiveness = 25
	alignPos.Parent = petRoot

	local alignRot = Instance.new("AlignOrientation")
	alignRot.Mode = Enum.OrientationAlignmentMode.TwoAttachment
	alignRot.Attachment0 = petAttachment
	alignRot.Attachment1 = charAttachment
	alignRot.MaxTorque = 15000
	alignRot.Responsiveness = 20
	alignRot.Parent = petRoot

	petModel.Parent = character
end

return PetSystem`,
  },
  {
    id: 'zone-detection-system',
    title: 'نظام مناطق آمنة ومناطق قتال (SafeZone & PvP Areas)',
    description: 'يتعرف على دخول وخروج اللاعب من مناطق مخصصة باستخدام Spatial Queries الفائقة السرعة لتفعيل وتعطيل الحماية.',
    category: 'systems',
    lang: 'luau',
    location: 'ServerScriptService',
    tags: ['Zones', 'SafeZone', 'PvP', 'OverlapParams'],
    content: `local RunService = game:GetService("RunService")
local Players = game:GetService("Players")

local safeZonePart = workspace:WaitForChild("SafeZoneBox") :: BasePart

local overlapParams = OverlapParams.new()
overlapParams.FilterType = RaycastFilterType.Include

local inSafeZone = {}

task.spawn(function()
	while true do
		task.wait(0.2)
		local parts = workspace:GetPartsInPart(safeZonePart)
		local currentInZone = {}

		for _, part in ipairs(parts) do
			local char = part:FindFirstAncestorOfClass("Model")
			local player = char and Players:GetPlayerFromCharacter(char)
			if player and not currentInZone[player] then
				currentInZone[player] = true
				if not inSafeZone[player] then
					inSafeZone[player] = true
					-- تفعيل الحماية
					local forceField = Instance.new("ForceField")
					forceField.Name = "SafeZoneShield"
					forceField.Parent = char
					print(player.Name .. " دخل المنطقة الآمنة")
				end
			end
		end

		-- إزالة الحماية عن الخارجين
		for player in pairs(inSafeZone) do
			if not currentInZone[player] then
				inSafeZone[player] = nil
				local char = player.Character
				if char and char:FindFirstChild("SafeZoneShield") then
					char.SafeZoneShield:Destroy()
					print(player.Name .. " غادر المنطقة الآمنة")
				end
			end
		end
	end
end)`,
  },
  {
    id: 'overhead-billboard-gui',
    title: 'لوحة فوق رأس اللاعب (Level, Clan, Rank BillboardGui)',
    description: 'تنشئ بطاقة معلومات عائمة فوق شخصية اللاعب عند الانضمام مع إظهار الاسم والمستوى ورتبة الكلان.',
    category: 'ui',
    lang: 'luau',
    location: 'ServerScriptService',
    tags: ['UI', 'BillboardGui', 'Rank', 'Level'],
    content: `local Players = game:GetService("Players")

local function attachOverhead(character: Model, player: Player)
	local head = character:WaitForChild("Head", 5)
	if not head then return end

	local billboard = Instance.new("BillboardGui")
	billboard.Name = "OverheadDisplay"
	billboard.Size = UDim2.fromScale(5, 1.8)
	billboard.StudsOffset = Vector3.new(0, 2.5, 0)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 60

	local frame = Instance.new("Frame")
	frame.Size = UDim2.fromScale(1, 1)
	frame.BackgroundTransparency = 0.3
	frame.BackgroundColor3 = Color3.fromRGB(15, 23, 42)
	frame.Parent = billboard

	local uiCorner = Instance.new("UICorner")
	uiCorner.CornerRadius = UDim.new(0, 8)
	uiCorner.Parent = frame

	local titleLabel = Instance.new("TextLabel")
	titleLabel.Size = UDim2.fromScale(1, 0.5)
	titleLabel.Text = player.DisplayName .. " (@" .. player.Name .. ")"
	titleLabel.TextColor3 = Color3.fromRGB(34, 211, 238)
	titleLabel.TextScaled = true
	titleLabel.Font = Enum.Font.GothamBold
	titleLabel.BackgroundTransparency = 1
	titleLabel.Parent = frame

	local subLabel = Instance.new("TextLabel")
	subLabel.Size = UDim2.fromScale(1, 0.4)
	subLabel.Position = UDim2.fromScale(0, 0.55)
	subLabel.Text = "★ محارب مخضرم | مستوى 42"
	subLabel.TextColor3 = Color3.fromRGB(241, 245, 249)
	subLabel.TextScaled = true
	subLabel.Font = Enum.Font.GothamMedium
	subLabel.BackgroundTransparency = 1
	subLabel.Parent = frame

	billboard.Parent = head
end

Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(function(char)
		attachOverhead(char, player)
	end)
end)`,
  },
  {
    id: 'prompt-complete-tycoon',
    title: 'برومبت AI متكامل لتوليد نظام Tycoon ضخم',
    description: 'برومبت مهندس بأعلى درجات الدقة لنسخه وإرساله إلى Gemini أو Claude لبناء لعبة تايكون أوتوماتيكية.',
    category: 'prompts',
    lang: 'text',
    tags: ['Prompt Engineering', 'AI Prompt', 'Tycoon'],
    content: `Role: Elite Roblox Luau Game Developer & Systems Architect.
Task: Write a clean, modular, and production-grade Tycoon Core System for Roblox Studio.

Architecture Requirements:
1. ReplicatedStorage/Modules/TycoonConfig: Contains all buttons, costs, dependent unlocks, droppers, and conveyor speeds.
2. ServerScriptService/TycoonServer: Handles claiming plots, purchasing items with server verification, dropper loops, and leaderstats cash generation.
3. StarterPlayerScripts/TycoonClient: Handles smooth purchase button UI feedback, floating purchase costs, and sound effects.

Strict Code Standards:
- Use task.spawn, task.wait, and task.delay (NEVER use legacy wait() or spawn()).
- Server-side validation: Players can only buy items if they are the verified owner of the tycoon plot and have enough Cash in their leaderstats.
- Proper cleanup: When a player leaves, unclaim the tycoon plot and reset all dropper loops gracefully.
- Provide clean comments explaining where to place each script.`,
  },
  {
    id: 'prompt-combat-swords',
    title: 'برومبت AI لنظام قتال سيوف 3D مع كومبو وضربات حركية',
    description: 'أمر ذكاء اصطناعي شامل لتوليد نظام قتال بالسيوف مع حركات متتالية وRaycast Hitbox دقيق.',
    category: 'prompts',
    lang: 'text',
    tags: ['Prompt', 'Combat', 'Animation', 'RaycastHitbox'],
    content: `Act as a senior Roblox Combat Developer.
Generate a high-polish 3-Hit Combo Sword Combat System in Luau.

Features required:
1. Client: Detects MouseClick, plays animations for Hit 1, Hit 2, and Hit 3 finisher with a 1.2s reset timer between clicks.
2. Hit Detection: Uses RaycastParams with Shapecast or spatial raycasts along the blade attachments to guarantee 100% accurate hits without relying on legacy Touched events.
3. Server: Verifies distance (< 12 studs), player character alive, cooldown timing, applies damage (15, 20, 35 for finisher), and spawns hit sound & particle emitter.
4. Camera Shake: Slight camera impulse on the 3rd finisher hit.

Provide complete scripts for Tool/Sword, ServerScriptService, and ReplicatedStorage.`,
  },
];
