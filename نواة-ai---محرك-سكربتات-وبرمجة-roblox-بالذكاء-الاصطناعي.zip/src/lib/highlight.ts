import type { CodeLang } from './types';

export type TokenType = 'keyword' | 'string' | 'number' | 'comment' | 'function' | 'builtin' | 'plain';
export type Token = { type: TokenType; value: string };

const KEYWORDS: Partial<Record<CodeLang, string[]>> = {
  luau: [
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function', 'if', 'in',
    'local', 'nil', 'not', 'or', 'repeat', 'return', 'then', 'true', 'until', 'while', 'continue', 'type', 'export',
  ],
  lua: [
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function', 'if', 'in',
    'local', 'nil', 'not', 'or', 'repeat', 'return', 'then', 'true', 'until', 'while',
  ],
  javascript: [
    'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'do', 'switch', 'case',
    'break', 'continue', 'new', 'class', 'extends', 'import', 'export', 'from', 'default', 'async',
    'await', 'try', 'catch', 'finally', 'throw', 'typeof', 'instanceof', 'of', 'in', 'true', 'false',
    'null', 'undefined', 'this', 'static', 'get', 'set',
  ],
  typescript: [
    'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'do', 'switch', 'case',
    'break', 'continue', 'new', 'class', 'extends', 'import', 'export', 'from', 'default', 'async',
    'await', 'try', 'catch', 'finally', 'throw', 'typeof', 'instanceof', 'of', 'in', 'true', 'false',
    'null', 'undefined', 'this', 'static', 'get', 'set', 'type', 'interface', 'enum', 'implements',
    'private', 'public', 'protected', 'readonly', 'as', 'keyof', 'number', 'string', 'boolean', 'void',
  ],
  tsx: [
    'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'import', 'export', 'from', 'default',
    'type', 'interface', 'async', 'await', 'as',
  ],
  python: [
    'def', 'return', 'if', 'elif', 'else', 'for', 'while', 'in', 'not', 'and', 'or', 'import', 'from',
    'as', 'class', 'try', 'except', 'finally', 'raise', 'with', 'lambda', 'yield', 'pass', 'break',
    'continue', 'True', 'False', 'None', 'is', 'async', 'await', 'self',
  ],
  json: ['true', 'false', 'null'],
  css: ['@media', '@keyframes', 'important', 'from', 'to'],
  html: [],
  text: [],
};

const BUILTINS: Partial<Record<CodeLang, string[]>> = {
  luau: [
    'game', 'workspace', 'script', 'Instance', 'Vector3', 'Vector2', 'CFrame', 'Color3', 'BrickColor', 'UDim2',
    'UDim', 'TweenInfo', 'Enum', 'task', 'print', 'warn', 'error', 'pairs', 'ipairs', 'math', 'string', 'table',
    'tostring', 'tonumber', 'typeof', 'pcall', 'xpcall', 'require', 'os', 'tick', 'time', 'self',
    'ReplicatedStorage', 'ServerScriptService', 'ServerStorage', 'Players', 'TweenService', 'RunService',
    'HttpService', 'DataStoreService', 'UserInputService', 'ContextActionService', 'SoundService',
    'Debris', 'MarketplaceService', 'BadgeService', 'TeleportService',
  ],
  lua: [
    'print', 'pairs', 'ipairs', 'math', 'string', 'table', 'tostring', 'tonumber', 'type', 'pcall', 'require', 'os',
  ],
  javascript: [
    'console', 'document', 'window', 'Math', 'JSON', 'Promise', 'Array', 'Object', 'Date', 'fetch', 'Number', 'String', 'Error',
  ],
  typescript: [
    'console', 'document', 'window', 'Math', 'JSON', 'Promise', 'Array', 'Object', 'Date', 'fetch', 'Number', 'String', 'Error',
  ],
  tsx: [
    'console', 'document', 'window', 'React', 'useState', 'useEffect', 'useMemo', 'useCallback', 'useRef',
  ],
  python: ['print', 'len', 'range', 'list', 'dict', 'str', 'int', 'float', 'open', 'enumerate', 'sorted', 'random', 'json'],
};

function commentPattern(lang: CodeLang): string {
  switch (lang) {
    case 'luau':
    case 'lua':
      return String.raw`--\[\[[\s\S]*?\]\]|--[^\n]*`;
    case 'python':
      return String.raw`#[^\n]*`;
    case 'html':
      return String.raw`<!--[\s\S]*?-->`;
    case 'css':
      return String.raw`\/\*[\s\S]*?\*\/`;
    default:
      return String.raw`\/\*[\s\S]*?\*\/|\/\/[^\n]*`;
  }
}

export function tokenize(code: string, lang: CodeLang): Token[] {
  if (lang === 'text') return [{ type: 'plain', value: code }];

  const keywords = KEYWORDS[lang] ?? [];
  const builtins = BUILTINS[lang] ?? [];

  const comm = commentPattern(lang);
  const str = String.raw`"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|` + '`(?:[^`\\\\]|\\\\.)*`' + (lang === 'luau' || lang === 'lua' ? String.raw`|\[\[[\s\S]*?\]\]` : '');
  const num = String.raw`\b0x[0-9a-fA-F]+\b|\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b`;
  const fn = String.raw`\b([A-Za-z_][A-Za-z0-9_]*)\s*(?=\()`;
  const ident = String.raw`[A-Za-z_][A-Za-z0-9_]*`;

  const master = new RegExp(
    `(${comm})|(${str})|(${num})|${fn}|(${ident})|([^\\s\\w]+)|(\\s+)`,
    'g'
  );

  const tokens: Token[] = [];
  let match: RegExpExecArray | null;

  while ((match = master.exec(code)) !== null) {
    const [full, comment, stringVal, numberVal, identVal, symbol, ws] = match;

    if (comment) {
      tokens.push({ type: 'comment', value: comment });
    } else if (stringVal) {
      tokens.push({ type: 'string', value: stringVal });
    } else if (numberVal) {
      tokens.push({ type: 'number', value: numberVal });
    } else if (match[4]) {
      const name = match[4];
      if (keywords.includes(name)) {
        tokens.push({ type: 'keyword', value: name });
      } else if (builtins.includes(name)) {
        tokens.push({ type: 'builtin', value: name });
      } else {
        tokens.push({ type: 'function', value: name });
      }
    } else if (identVal) {
      if (keywords.includes(identVal)) {
        tokens.push({ type: 'keyword', value: identVal });
      } else if (builtins.includes(identVal)) {
        tokens.push({ type: 'builtin', value: identVal });
      } else {
        tokens.push({ type: 'plain', value: identVal });
      }
    } else if (symbol) {
      tokens.push({ type: 'plain', value: symbol });
    } else if (ws) {
      tokens.push({ type: 'plain', value: ws });
    } else if (full) {
      tokens.push({ type: 'plain', value: full });
    }
  }

  return tokens;
}

export const LANG_LABELS: Record<CodeLang, string> = {
  luau: 'Roblox Luau',
  lua: 'Lua Script',
  javascript: 'JavaScript',
  typescript: 'TypeScript',
  tsx: 'React TSX',
  python: 'Python',
  html: 'HTML5',
  css: 'CSS3',
  json: 'JSON',
  text: 'نص عادي',
};
