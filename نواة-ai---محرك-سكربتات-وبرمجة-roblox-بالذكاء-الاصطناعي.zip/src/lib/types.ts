export type CodeLang =
  | 'luau'
  | 'lua'
  | 'javascript'
  | 'typescript'
  | 'tsx'
  | 'python'
  | 'html'
  | 'css'
  | 'json'
  | 'text';

export type Block =
  | { kind: 'heading'; content: string }
  | { kind: 'text'; content: string }
  | { kind: 'list'; items: string[]; ordered?: boolean }
  | { kind: 'code'; lang: CodeLang; content: string; title?: string; location?: string }
  | { kind: 'note'; tone: 'info' | 'warn' | 'success'; content: string };

export type EngineResult = {
  blocks: Block[];
  rawText?: string;
};

export type EngineOption = {
  id: string;
  label: string;
  choices: { value: string; label: string }[];
};

export type EngineId = 'architect' | 'security' | 'debugger' | 'ui' | 'prompt' | 'luau_classic';

export type Engine = {
  id: EngineId;
  name: string;
  tagline: string;
  badge: string;
  iconName: string;
  placeholder: string;
  suggestions: string[];
  options: EngineOption[];
  systemPrompt: string;
  runLocal?: (input: string, options: Record<string, string>) => EngineResult;
};

export type TabId = 'workspace' | 'generator' | 'library' | 'sandbox' | 'pressure';

export type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  engineId: EngineId;
  content: string;
  blocks?: Block[];
  status?: 'thinking' | 'streaming' | 'done' | 'error';
  modelUsed?: string;
  timestamp?: string;
  latencyMs?: number;
};

export type FieldType = 'text' | 'number' | 'boolean' | 'select';

export type GeneratorField = {
  id: string;
  label: string;
  type: FieldType;
  default: string | number | boolean;
  hint?: string;
  min?: number;
  max?: number;
  step?: number;
  options?: { value: string; label: string }[];
};

export type GeneratedFile = {
  name: string;
  location: string;
  scriptType: 'Script' | 'LocalScript' | 'ModuleScript';
  code: string;
};

export type ScriptTemplate = {
  id: string;
  name: string;
  category: 'gameplay' | 'backend' | 'security' | 'ui' | 'economy';
  description: string;
  fields: GeneratorField[];
  setup: string[];
  build: (v: Record<string, string | number | boolean>) => GeneratedFile[];
};

export type LibraryCategory = 'all' | 'gameplay' | 'security' | 'systems' | 'ui' | 'prompts';

export type LibraryItem = {
  id: string;
  title: string;
  description: string;
  category: LibraryCategory;
  lang: CodeLang;
  tags: string[];
  location?: string;
  content: string;
};
