import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  Download, 
  PanelLeftClose, 
  PanelLeft, 
  Code2, 
  Bot, 
  User, 
  RotateCcw,
  Zap,
  Cpu,
  ChevronDown
} from 'lucide-react';
import { streamGeminiChat, type BenchmarkStats } from './lib/gemini-client';
import { tokenize, type TokenType } from './lib/highlight';
import { downloadFile } from './lib/utils';
import type { Block, ChatMessage, CodeLang } from './lib/types';

// Gemini Syntax Token Colors (Clean, Muted Gray & Minimalist)
const TOKEN_COLORS: Record<TokenType, string> = {
  keyword: 'text-sky-400 font-medium',
  builtin: 'text-violet-400',
  string: 'text-emerald-400',
  number: 'text-amber-300',
  comment: 'text-zinc-500 italic',
  function: 'text-blue-300',
  plain: 'text-zinc-200',
};

function CleanCodeBlock({ code, lang = 'luau', title }: { code: string; lang?: CodeLang; title?: string }) {
  const [copied, setCopied] = useState(false);
  const tokens = tokenize(code, lang);
  const lines = code.split('\n');

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const ext = lang === 'luau' || lang === 'lua' ? 'luau' : lang;
    downloadFile(title || `script.${ext}`, code, 'text/plain');
  };

  return (
    <div className="my-4 rounded-xl border border-zinc-800 bg-[#131314] overflow-hidden shadow-md" dir="ltr">
      <div className="flex items-center justify-between px-4 py-2 border-b border-zinc-800/80 bg-[#18191b] text-xs text-zinc-400">
        <span className="font-mono text-zinc-300 font-medium">{title || lang}</span>
        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-800/60 hover:bg-zinc-700/80 hover:text-zinc-200 transition-all"
            title="تحميل الملف"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="text-[11px]">تحميل</span>
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-800/60 hover:bg-zinc-700/80 hover:text-zinc-200 transition-all"
            title="نسخ الكود"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="text-[11px]">{copied ? 'تم النسخ' : 'نسخ'}</span>
          </button>
        </div>
      </div>

      <div className="p-4 font-mono text-[13px] leading-relaxed overflow-x-auto text-left">
        <div className="flex">
          <div className="select-none text-right pr-4 text-zinc-600 border-r border-zinc-800/80 min-w-[2.5rem]">
            {lines.map((_, i) => (
              <div key={i}>{i + 1}</div>
            ))}
          </div>
          <div className="pl-4 flex-1 whitespace-pre">
            {tokens.map((token, idx) => (
              <span key={idx} className={TOKEN_COLORS[token.type]}>
                {token.value}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const STARTER_PROMPTS = [
  {
    title: 'نظام متجر وترقية أسلحة',
    desc: 'مع التحقق من الرصيد على الخادم ومؤثرات صوتية',
    prompt: 'اكتب لي نظام متجر وترقية أسلحة كامل يربط بين الخادم والعميل مع فحص الرصيد على الخادم ومؤثرات صوتية.',
  },
  {
    title: 'حفظ بيانات اللاعبين (DataStore)',
    desc: 'حفظ الكوينز والمستوى مع الحفظ التلقائي',
    prompt: 'اكتب سكربت متكامل لحفظ واسترجاع بيانات اللاعبين (Coins, Level, Gems) باستخدام DataStoreService مع الحفظ التلقائي.',
  },
  {
    title: 'نظام حماية من الهاكات (Anti-Cheat)',
    desc: 'منع تسريع المشي والطيران من طرف الخادم',
    prompt: 'اكتب نظام حماية Server-Side متطور لمنع الطيران وتجاوز السرعة القصوى (Anti-Fly & Anti-Speed).',
  },
  {
    title: 'نظام قتال وأسلحة Raycast',
    desc: 'إطلاق نار فيزيائي مع التحقق من الإصابة',
    prompt: 'اكتب نظام سلاح يعتمد على Raycast مع فحص الضرر على الخادم ومنع استغلال الـ RemoteEvent.',
  },
];

export default function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [chatSessions, setChatSessions] = useState<{ id: string; title: string; date: string }[]>([
    { id: '1', title: 'محادثة جديدة', date: 'اليوم' },
  ]);
  const [activeSessionId, setActiveSessionId] = useState('1');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isGenerating]);

  // Adjust textarea height automatically
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = (customPrompt || input).trim();
    if (!textToSend || isGenerating) return;

    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    const userMsgId = 'user-' + Date.now();
    const assistantMsgId = 'asst-' + (Date.now() + 1);

    const userMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      engineId: 'architect',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    const initialAssistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      engineId: 'architect',
      content: '',
      status: 'thinking',
      blocks: [],
      modelUsed: 'gemini-3.8-flash',
    };

    setMessages((prev) => [...prev, userMsg, initialAssistantMsg]);
    setIsGenerating(true);

    // Update session title if first message
    if (messages.length === 0) {
      setChatSessions((prev) =>
        prev.map((s) => (s.id === activeSessionId ? { ...s, title: textToSend.slice(0, 30) } : s))
      );
    }

    await streamGeminiChat({
      prompt: textToSend,
      engineId: 'architect',
      history: messages,
      model: 'gemini-3.8-flash',
      onChunk: (accumulated) => {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'streaming',
                  content: accumulated,
                }
              : m
          )
        );
      },
      onDone: (finalBlocks, stats, rawText) => {
        setIsGenerating(false);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'done',
                  blocks: finalBlocks,
                  content: rawText,
                  modelUsed: stats.model,
                }
              : m
          )
        );
      },
      onError: (errorMsg) => {
        setIsGenerating(false);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  status: 'error',
                  content: errorMsg,
                }
              : m
          )
        );
      },
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const startNewChat = () => {
    const newId = String(Date.now());
    setChatSessions((prev) => [{ id: newId, title: 'محادثة جديدة', date: 'الآن' }, ...prev]);
    setActiveSessionId(newId);
    setMessages([]);
    setInput('');
  };

  return (
    <div className="flex h-screen w-screen bg-[#0e0e10] text-[#e3e3e3] font-sans antialiased overflow-hidden selection:bg-zinc-700 selection:text-white" dir="rtl">
      
      {/* Gemini Minimal Left Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-0'
        } transition-all duration-300 ease-in-out border-l border-zinc-800/60 bg-[#131314] flex flex-col shrink-0 overflow-hidden z-20`}
      >
        <div className="p-3 border-b border-zinc-800/60 flex items-center justify-between">
          <button
            onClick={startNewChat}
            className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-full bg-[#1e1f20] hover:bg-[#282a2c] text-xs font-medium text-zinc-200 border border-zinc-700/50 transition-all"
          >
            <Plus className="w-4 h-4 text-zinc-300" />
            <span>محادثة جديدة</span>
          </button>
        </div>

        {/* Chat History List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          <div className="px-3 py-1.5 text-[11px] font-semibold text-zinc-500 uppercase tracking-wider">
            المحادثات الأخيرة
          </div>
          {chatSessions.map((session) => (
            <div
              key={session.id}
              onClick={() => setActiveSessionId(session.id)}
              className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs cursor-pointer transition-all ${
                activeSessionId === session.id
                  ? 'bg-[#1e1f20] text-zinc-100 font-medium'
                  : 'text-zinc-400 hover:bg-[#1a1a1c] hover:text-zinc-200'
              }`}
            >
              <span className="truncate">{session.title}</span>
            </div>
          ))}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-zinc-800/60 text-[11px] text-zinc-500 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Gemini 3.8 Flash</span>
          </span>
          <span>مجاني للضغط العالي</span>
        </div>
      </aside>

      {/* Main Chat Container */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#0e0e10] relative">
        
        {/* Clean Gemini Top Bar */}
        <header className="h-14 border-b border-zinc-800/60 flex items-center justify-between px-4 sm:px-6 bg-[#0e0e10] shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-[#1e1f20] transition-all"
              title="القائمة الجانبية"
            >
              {sidebarOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
            </button>
            
            <div className="flex items-center gap-2">
              <span className="font-bold text-base text-zinc-100">Gemini</span>
              <span className="text-xs px-2 py-0.5 rounded-md bg-[#1e1f20] text-zinc-400 font-mono border border-zinc-800">
                3.8 Flash
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={startNewChat}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-[#1e1f20] transition-all"
              title="إعادة ضبط المحادثة"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Scrollable Chat Area */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 max-w-4xl w-full mx-auto space-y-6">
          
          {/* Empty State (Greeting like Gemini) */}
          {messages.length === 0 && (
            <div className="h-full flex flex-col justify-center items-center text-center my-auto py-12 space-y-8">
              <div className="space-y-3 max-w-lg">
                <div className="w-12 h-12 rounded-2xl bg-[#1e1f20] border border-zinc-800 flex items-center justify-center mx-auto text-sky-400">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-zinc-100">
                  مرحباً بك، كيف يمكنني مساعدتك اليوم؟
                </h1>
                <p className="text-sm text-zinc-400 leading-relaxed">
                  اطلب أي كود Luau، نظام ألعاب، تصحيح أخطاء، أو بنية أمان في روبلوكس بستخدام نموذج Gemini 3.8 Flash المجاني فائق السرعة.
                </p>
              </div>

              {/* Minimal Clean Prompt Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl text-right">
                {STARTER_PROMPTS.map((card, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(card.prompt)}
                    className="p-4 rounded-xl bg-[#131314] hover:bg-[#1a1b1d] border border-zinc-800/80 hover:border-zinc-700 transition-all text-right group"
                  >
                    <div className="font-semibold text-sm text-zinc-200 group-hover:text-sky-300 transition-colors">
                      {card.title}
                    </div>
                    <div className="text-xs text-zinc-400 mt-1 line-clamp-1">{card.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Conversation Messages */}
          {messages.map((message) => {
            const isUser = message.role === 'user';
            return (
              <div key={message.id} className="flex gap-4 items-start">
                
                {/* Avatar */}
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                    isUser
                      ? 'bg-zinc-700 text-zinc-200'
                      : 'bg-gradient-to-tr from-sky-500 to-indigo-600 text-white shadow-sm'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Sparkles className="w-3.5 h-3.5" />}
                </div>

                {/* Body */}
                <div className="flex-1 space-y-2 overflow-hidden">
                  <div className="text-xs font-semibold text-zinc-400">
                    {isUser ? 'أنت' : 'Gemini'}
                  </div>

                  {message.status === 'thinking' && (
                    <div className="flex items-center gap-2 text-zinc-400 text-xs py-2">
                      <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                      <span>جاري التفكير والتوليد...</span>
                    </div>
                  )}

                  {/* Text / Markdown Content */}
                  {message.content && (!message.blocks || message.blocks.length === 0) && (
                    <div className="text-sm text-zinc-200 leading-relaxed whitespace-pre-wrap select-text">
                      {message.content}
                    </div>
                  )}

                  {/* Blocks */}
                  {message.blocks && message.blocks.length > 0 && (
                    <div className="space-y-3">
                      {message.blocks.map((block, idx) => {
                        if (block.kind === 'heading') {
                          return (
                            <h3 key={idx} className="font-bold text-base text-zinc-100 mt-3 mb-1">
                              {block.content}
                            </h3>
                          );
                        }
                        if (block.kind === 'text') {
                          return (
                            <p key={idx} className="text-sm text-zinc-300 leading-relaxed whitespace-pre-wrap select-text">
                              {block.content}
                            </p>
                          );
                        }
                        if (block.kind === 'note') {
                          return (
                            <div key={idx} className="p-3 rounded-lg bg-[#18191b] border border-zinc-800 text-xs text-zinc-300">
                              {block.content}
                            </div>
                          );
                        }
                        if (block.kind === 'code') {
                          return (
                            <CleanCodeBlock
                              key={idx}
                              code={block.content}
                              lang={block.lang}
                              title={block.title}
                            />
                          );
                        }
                        return null;
                      })}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Gemini Rounded Floating Input Pill */}
        <div className="p-4 sm:pb-6 max-w-4xl w-full mx-auto shrink-0">
          <div className="relative rounded-2xl bg-[#1e1f20] border border-zinc-800 focus-within:border-zinc-700 shadow-xl transition-all">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isGenerating}
              placeholder="اسأل Gemini عن أي سكربت أو نظام في روبلوكس..."
              rows={1}
              className="w-full bg-transparent px-4 py-3.5 pl-12 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none resize-none max-h-48 leading-relaxed"
            />

            <div className="absolute left-2.5 bottom-2.5 flex items-center">
              <button
                onClick={() => handleSend()}
                disabled={!input.trim() || isGenerating}
                className={`p-2 rounded-full transition-all ${
                  !input.trim() || isGenerating
                    ? 'text-zinc-600 bg-transparent cursor-not-allowed'
                    : 'text-white bg-sky-500 hover:bg-sky-400 active:scale-95 shadow-md'
                }`}
                title="إرسال"
              >
                <Send className="w-4 h-4 rotate-180" />
              </button>
            </div>
          </div>
          <p className="text-[11px] text-zinc-500 text-center mt-2">
            يعتمد على Google Gemini 3.8 Flash المجاني المخصص لتحمل الضغط العالي.
          </p>
        </div>
      </div>
    </div>
  );
}
